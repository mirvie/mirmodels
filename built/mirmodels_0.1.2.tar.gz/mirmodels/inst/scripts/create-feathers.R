pacman::p_load(mirviemisc, tidyverse, arrow, here, fs, measurements, magrittr)

create_race_factor <- function(x) {
  checkmate::assert_character(x)
  x <- if_else(stringr::str_detect(x, stringr::coll("hispanic", TRUE)),
               "hispanic", x)
  x <- if_else(is.na(x), "unknown", x)
  factor(x,
         levels = c("afro_american", "asian", "hispanic", "white", "unknown"))
}

create_pca_outlier_df <- function(metadata, raw_counts) {
  counts <- suppressWarnings(
    bind_cols(keep(raw_counts, ~!isTRUE(median(.) <= 0)))
  ) %>% {
    bind_cols(
      .["mirvie_id"],
      map_dfc(select(., -mirvie_id), ~log2(. + 1)),
      tot_counts = log2(apply(select(., -mirvie_id), 1, sum) + 1)
    )
  }
  lab_outliers <- readr::read_lines(
    system.file("extdata", "lab-failures.txt", package = "mirviemodels")
  )
  data <- inner_join(counts, metadata, by = c("mirvie_id" = "mirvie_id")) %>%
    filter(!is.na(meta_collectionga), ACTB > 0,
           !(mirvie_id %in% lab_outliers))
  suppressWarnings(get_cohort_outliers(data)) %>%
    select(mirvie_id, outlier) %>%
    rename(meta_pca_outlier = outlier)
}

# BWH --------------------------------------------------------------------------
metadata <- path(
  "/Volumes/GoogleDrive/Shared drives/MirvieData/",
  "DataSeq/Cohorts/metadata/013_BW/200805_013_BW_metadata_CURATED.csv"
) %>%
  read_csv(col_types = cols()) %>%
  filter(!is.na(mirvie_id),
         readr::parse_number(as.character(batch_number)) != 6) %>%
  transmute(mirvie_id = as.character(mirvie_id),
            collectionga = collectionga,
            deliveryga = deliveryga,
            weeks_to_delivery = abs(time_to_deliv),
            sample_type = factor(sample_study_type),
            study_purpose = factor(primary_study_purpose),
            major_race = create_race_factor(major_race),
            mom_id = as.character(mom_id),
            collection_num = as.integer(collection_num),
            case_control_match_id = as.character(case_control_match_id),
            min_before_spin = min_before_spin,
            mom_bmi = m_bmi,
            sga = as.logical(sga_plos),
            pre_eclampsia = study_purpose == "pe" & sample_type == "case",
            baby_weight_g = baby_weight_g,
            batch_num = as.integer(batch_number),
            sample_volume_ul = sample_volume_ul,
            q_pcr_actb_ct = q_pcr_actb_ct,
            q_pcr_ercc_ct = suppressWarnings(as.numeric(q_pcr_ercc_ct))) %>%
  set_names(
    if_else(names(.) == "mirvie_id", names(.), paste0("meta_", names(.)))
  )
raw_counts <- collect_counts(here("inst", "extdata", "raw-counts", "BW")) %>%
  data.frame(row.names = "gene") %>%
  t() %>%
  as_tibble(rownames = "mirvie_id")
checkmate::assert_character(raw_counts$mirvie_id, unique = TRUE)
write_feather(raw_counts,
              here("inst", "extdata", "feathers", "BW_raw_counts.feather"),
              compression = "uncompressed")
outlier_df <- create_pca_outlier_df(metadata = metadata,
                                    raw_counts = raw_counts)
metadata <- left_join(metadata, outlier_df, by = c("mirvie_id" = "mirvie_id"))
checkmate::assert_character(metadata$mirvie_id, unique = TRUE)
write_feather(metadata, here("inst", "extdata", "feathers", "BW_meta.feather"),
              compression = "uncompressed")


# GAPPS ------------------------------------------------------------------------
metadata <- read_csv(
  path("/Volumes/GoogleDrive/Shared drives/MirvieData",
       "DataSeq/Cohorts/metadata/003_GA/191203_gapps_ga_metadata_CURATED.csv"),
  col_types = cols()
) %>%
  transmute(mirvie_id = as.character(mirvie_id),
            mom_id = as.character(mom_id),
            major_race = create_race_factor(major_race),
            ethnicity = ethnicity,
            mom_age = m_age,
            deliveryga = deliveryga,
            parity = as.numeric(parity) %/% 10,
            prom = is_prom,
            pprom = is_pprom,
            iugr = is_iugr,
            pre_eclampsia = is_m_pre_eclampsia,
            smoker = is_m_smoker,
            labor_spontaneous = as.logical(is_labor_spontaneous),
            labor_augmented = is_labor_augmented,
            labor_induced_complication = is_labor_induced_complication,
            labor_induced_elective = is_labor_induced_elective,
            ivf = is_ivf,
            chronic_hypertension = is_m_chronic_hypertension,
            collectionga = collectionga,
            min_before_spin = min_before_spin,
            n_prior_term_deliveries = m_prior_term_deliveries,
            n_prior_preterm_deliveries = m_prior_preterm_deliveries,
            baby_sex = baby_sex,
            baby_weight_g = baby_weight_g,
            weeks_to_delivery = abs(time_to_deliv),
            sample_volume_ul = sample_volume_ul,
            q_pcr_actb_ct = q_pcr_actb_ct,
            q_pcr_ercc_ct = suppressWarnings(as.numeric(q_pcr_ercc_ct))) %>%
  set_names(
    if_else(names(.) == "mirvie_id", names(.), paste0("meta_", names(.)))
  )
raw_counts <- collect_counts(here("inst", "extdata", "raw-counts", "GA")) %>%
  data.frame(row.names = "gene") %>%
  t() %>%
  as_tibble(rownames = "mirvie_id")
checkmate::assert_character(raw_counts$mirvie_id, unique = TRUE)
write_feather(raw_counts,
              here("inst", "extdata", "feathers", "GA_raw_counts.feather"),
              compression = "uncompressed")
outlier_df <- create_pca_outlier_df(metadata = metadata,
                                    raw_counts = raw_counts)
metadata <- left_join(metadata, outlier_df, by = c("mirvie_id" = "mirvie_id"))
checkmate::assert_character(metadata$mirvie_id, unique = TRUE)
write_feather(metadata, here("inst", "extdata", "feathers", "GA_meta.feather"),
              compression = "uncompressed")

# Validation GAPPS -------------------------------------------------------------
metadata <- read_csv(
  path("/Volumes/GoogleDrive/Shared drives/MirvieData",
       "DataSeq/Cohorts/metadata/009_VG/201013_009_VG_metadata_CURATED.csv"),
  col_types = cols()
) %>%
  janitor::clean_names() %>%
  transmute(mirvie_id = as.character(mirvie_id),
            mom_id = as.character(mom_id),
            major_race = create_race_factor(major_race),
            ethnicity = ethnicity,
            mom_age = m_age,
            collectionga = collectionga,
            deliveryga = deliveryga,
            smoker = is_m_smoker,
            baby_sex = baby_sex,
            baby_weight_g = baby_weight_g,
            weeks_to_delivery = deliveryga - collectionga,
            q_pcr_actb_ct = q_pcr_actb_ct,
            q_pcr_ercc_ct = suppressWarnings(as.numeric(q_pcr_ercc_ct))) %>%
  set_names(
    if_else(names(.) == "mirvie_id", names(.), paste0("meta_", names(.)))
  )
raw_counts <- collect_counts(here("inst", "extdata", "raw-counts", "VG")) %>%
  data.frame(row.names = "gene") %>%
  t() %>%
  as_tibble(rownames = "mirvie_id")
checkmate::assert_character(raw_counts$mirvie_id, unique = TRUE)
write_feather(raw_counts,
              here("inst", "extdata", "feathers", "VG_raw_counts.feather"),
              compression = "uncompressed")
outlier_df <- create_pca_outlier_df(metadata = metadata,
                                    raw_counts = raw_counts)
metadata <- left_join(metadata, outlier_df, by = c("mirvie_id" = "mirvie_id"))
checkmate::assert_character(metadata$mirvie_id, unique = TRUE)
write_feather(metadata, here("inst", "extdata", "feathers", "VG_meta.feather"),
              compression = "uncompressed")


# Preterm GAPPS ----------------------------------------------------------------
metadata <- read_csv(
  path("/Volumes/GoogleDrive/Shared drives/MirvieData/DataSeq/Cohorts",
       "metadata/004_PG/190820_gapps_preterm_metadata_CURATED.csv"),
  col_types = cols()
) %>%
  transmute(mirvie_id = as.character(mirvie_id),
            major_race = create_race_factor(major_race),
            ethnicity = u_ethnicity,
            deliveryga = deliveryga,
            mom_age = m_age,
            prom = prom,
            pprom = pprom,
            normal_delivery = str_detect(delivery_type,
                                         coll("normal", ignore_case = TRUE)),
            caesarean = str_detect(delivery_type,
                                   coll("c-section", ignore_case = TRUE)),
            smoker = smoker,
            labor_spontaneous = str_detect(labor_type, coll("spont", TRUE)),
            baby_sex = factor(babygender),
            collectionga = collectionga,
            weeks_to_delivery = deliveryga - collectionga,
            min_before_spin = minutes_before_spin,
            sample_volume_ul = sample_volume_ul,
            q_pcr_actb_ct = q_pcr_actb_ct,
            q_pcr_ercc_ct = q_pcr_ercc_ct
  ) %>%
  set_names(
    if_else(names(.) == "mirvie_id", names(.), paste0("meta_", names(.)))
  )
raw_counts <- collect_counts(here("inst", "extdata", "raw-counts", "PG")) %>%
  data.frame(row.names = "gene") %>%
  t() %>%
  as_tibble(rownames = "mirvie_id")
checkmate::assert_character(raw_counts$mirvie_id, unique = TRUE)
write_feather(raw_counts,
              here("inst", "extdata", "feathers", "PG_raw_counts.feather"),
              compression = "uncompressed")
outlier_df <- create_pca_outlier_df(metadata = metadata,
                                    raw_counts = raw_counts)
metadata <- left_join(metadata, outlier_df, by = c("mirvie_id" = "mirvie_id"))
checkmate::assert_character(metadata$mirvie_id, unique = TRUE)
write_feather(metadata, here("inst", "extdata", "feathers", "PG_meta.feather"),
              compression = "uncompressed")


# Iowa -------------------------------------------------------------------------
metadata <- read_csv(
  path("/Volumes/GoogleDrive/Shared drives/MirvieData",
       "DataSeq/Cohorts/metadata/006_IO",
       "190924_IO_PTB_metadata_CURATED.csv"),
  col_types = cols()
) %>%
  transmute(
    mirvie_id = as.character(mirvie_id),
    mom_id = as.character(mom_id),
    sample_type = tolower(sample_study_type),
    major_race = create_race_factor(
      case_when(
        major_race == "White" ~ "white",
        str_detect(major_race, "Hispanic") ~ "hispanic",
        str_detect(major_race, "African American") ~ "afro_american",
        TRUE ~ NA_character_
      )
    ),
    mom_bmi = m_bmi,
    smoker = is_m_smokes,
    pre_eclampsia = is_m_pre_eclampsia,
    parity = m_parity,
    labor_spontaneous = is_labor_spontaneous,
    baby_weight_g = baby_weight_g,
    baby_length_cm = baby_length_cm,
    stillbirth = is_stillbirth,
    collectionga = collectionga,
    deliveryga = deliveryga,
    weeks_to_delivery = time_to_deliv,
    mom_age = m_age,
    caesarean = is_delivery_ceasarean,
    q_pcr_actb_ct = q_pcr_actb_ct,
    q_pcr_ercc_ct = suppressWarnings(as.numeric(q_pcr_ercc_ct))
  ) %>%
  set_names(
    if_else(names(.) == "mirvie_id", names(.), paste0("meta_", names(.)))
  ) %>%
  filter(!duplicated(mirvie_id))
raw_counts <- collect_counts(here("inst", "extdata", "raw-counts", "IO")) %>%
  data.frame(row.names = "gene") %>%
  t() %>%
  as_tibble(rownames = "mirvie_id")
checkmate::assert_character(raw_counts$mirvie_id, unique = TRUE)
write_feather(raw_counts,
              here("inst", "extdata", "feathers", "IO_raw_counts.feather"),
              compression = "uncompressed")
outlier_df <- create_pca_outlier_df(metadata = metadata,
                                    raw_counts = raw_counts)
metadata <- left_join(metadata, outlier_df, by = c("mirvie_id" = "mirvie_id"))
checkmate::assert_character(metadata$mirvie_id, unique = TRUE)
write_feather(metadata, here("inst", "extdata", "feathers", "IO_meta.feather"),
              compression = "uncompressed")

# King's -----------------------------------------------------------------------
metadata <- read_csv(
  path("/Volumes/GoogleDrive/Shared drives/MirvieData",
       "DataSeq/Cohorts/metadata/012_KL",
       "200902_012_KL_kcl_metadata_CURATED.csv"),
  col_types = cols()
) %>%
  filter(!is.na(mirvie_id)) %>%
  transmute(mirvie_id = as.character(mirvie_id),
            major_race = create_race_factor(major_race),
            sample_type = sample_study_type,
            case_control_match_id = as.character(case_control_match_id),
            prev_pprom = previous_pprom,
            prev_late_miscarriage = previous_late_miscarriage,
            prev_cervical_surgery = previous_cervical_surgery,
            low_risk_at_enrollment = low_risk_at_enrollment,
            type_2_diabetes = type_2_diabetes,
            autoimmune_disease = autoimmune_disease,
            chronic_viral_infection = chronic_viral_infection,
            antihypertensives = antihypertensives,
            immunosuppressants = immunosuppressive_agents,
            mom_height_cm = height,
            mom_weight_kg = weight,
            mom_bmi = m_bmi,
            mom_age = m_age,
            ethnicity = str_replace_all(str_extract(ethnicity, "[A-Z][^(]+"),
                                        " ", ""),
            bv_history = past_or_present_history_of_bv,
            smoker = str_replace_all(m_smoking_notes, " .+", "") == "Current",
            first_pregnancy = primigravida,
            n_prior_preg_0_13 = no_of_pregnancies_ending_13_0_weeks_or_earlier,
            n_prior_preg_14_23 = no_of_pregnancies_ending_14_0_23_6_weeks,
            n_prior_preg_24_plus = no_of_pregnancies_ending_24_0_weeks_or_later,
            n_prior_preg_37_plus = no_of_pregnancies_ending_37_0_weeks_or_later,
            tocolysis = received_tocolysis,
            steroids_fetal_lung = received_steroids_for_fetal_lung_maturation,
            antibiotics = case_when(
              received_antibiotics == "Yes" ~ TRUE,
              received_antibiotics == "No" ~ FALSE,
              TRUE ~ NA
            ),
            progesterone = received_progesterone,
            emergengy_cerclage = received_emergency_cerclage,
            mag_sulph = mag_sulph_for_fetal_neuroprotection,
            maternal_pyrexia = maternal_pyrexia,
            crp_highest_value = crp_highest_value_recorded,
            wcc_highest_value = wcc_highest_value_recorded,
            blood_loss_ml = blood_loss_m_l,
            threatened_preterm_labor = threatened_preterm_labour,
            pprom = case_when(
              is.na(premature_prelabour_rupture_of_membranes) ~ NA,
              premature_prelabour_rupture_of_membranes == "Yes" ~ TRUE,
              premature_prelabour_rupture_of_membranes == "No" ~ FALSE,
              TRUE ~ NA
            ),
            obstetric_cholestasis = obstetric_cholestasis,
            antepartum_haemorrhage = antepartum_haemorrhage,
            vital_status = vital_status_disch,
            miscarriage = str_detect(tolower(vital_status), "miscarriage"),
            stillbirth = str_detect(tolower(vital_status), "miscarriage"),
            baby_sex = case_when(
              gender == "Male" ~ "M",
              gender == "Female" ~ "F",
              TRUE ~ NA_character_
            ),
            baby_weight_g = baby_weight_g,
            apgar = (apgar_1 + apgar_5) / 2,
            sbcu_or_nicu = admission_to_scbu_or_nicu,
            neonatal_inpatient_nights = number_of_inpatient_nights_neonatal,
            hrs_rom_to_delivery =
              time_between_rupture_of_membranes_and_delivery_hours,
            min_before_spin = min_before_spin,
            collectionga = collectionga,
            deliveryga = deliveryga,
            weeks_to_delivery = abs(time_to_deliv),
            study_purpose = primary_study_purpose,
            mom_gdm = is_m_gdm,
            pre_eclampsia = is_m_pre_eclampsia,
            chronic_hypertension = is_m_chronic_hypertension,
            mom_gbs = is_m_gbs,
            non_gdm_diabetic = is_diabetic_not_gdm,
            normal_delivery = is_delivery_normal,
            labor_spontaneous = delivery_notes %in% c(
              "Instrumental vaginal", "Emergency caesarean in labour",
              "Spontaneous vaginal"
            ),
            n_prior_preterm_deliveries = m_prior_preterm_deliveries,
            q_pcr_actb_ct = q_pcr_actb_ct,
            q_pcr_ercc_ct = q_pcr_ercc_ct) %>%
  set_names(
    if_else(names(.) == "mirvie_id", names(.), paste0("meta_", names(.)))
  )
raw_counts <- collect_counts(here("inst", "extdata", "raw-counts", "KL")) %>%
  data.frame(row.names = "gene") %>%
  t() %>%
  as_tibble(rownames = "mirvie_id")
checkmate::assert_character(raw_counts$mirvie_id, unique = TRUE)
write_feather(
  raw_counts,
  here("inst", "extdata", "feathers", "KL_raw_counts.feather"),
  compression = "uncompressed"
)
outlier_df <- create_pca_outlier_df(metadata = metadata,
                                    raw_counts = raw_counts)
metadata <- left_join(metadata, outlier_df, by = c("mirvie_id" = "mirvie_id"))
checkmate::assert_character(metadata$mirvie_id, unique = TRUE)
write_feather(metadata, here("inst", "extdata", "feathers", "KL_meta.feather"),
              compression = "uncompressed")


# MSU --------------------------------------------------------------------------
metadata <- path(
  "/Volumes/GoogleDrive/Shared drives/MirvieData",
  "DataSeq/Cohorts/metadata/005_MS/201211_005_MS_metadata_CURATED.csv"
) %>%
  read_csv(col_types = cols()) %>%
  transmute(mirvie_id = as.character(mirvie_id),
            batch_num = as.integer(batch_number),
            major_race = create_race_factor(major_race),
            sample_type = factor(sample_study_type),
            case_control_match_id = strex::str_alphord_nums(
              case_control_match_id
            ),
            study_purpose = factor(primary_study_purpose),
            collectionga = collectionga,
            deliveryga = deliveryga,
            weeks_to_delivery = abs(time_to_deliv),
            education = factor(strex::str_alphord_nums(m_education)),
            pe_htn = factor(pe_htn),
            gravida = m_gravida,
            parity = m_parity,
            n_prior_term_deliveries = m_prior_term_deliveries,
            n_prior_preterm_deliveries = m_prior_preterm_deliveries,
            baby_weight_g = baby_weight_g,
            prenatal_screening_ga = prenatal_screening_ga,
            mom_bmi = m_bmi,
            mom_age = m_age,
            baby_sex = baby_sex,
            ga_method = ga_method,
            conception_assisted = is_conception_assisted,
            sga = is_sga,
            mom_gdm = is_m_gdm,
            lupus = is_m_lupus,
            chronic_hypertension = is_m_chronic_hypertension,
            pre_eclampsia = is_m_pre_eclampsia,
            antibiotics = is_m_drug_antibiotics,
            stillbirth = is_stillbirth,
            caesarean = is_delivery_ceasarean,
            pprom = is_pprom,
            labor_spontaneous = is_labor_spontaneous,
            labor_induced_complication = is_labor_induced_complication,
            sample_volume_ul = sample_volume_ul,
            q_pcr_actb_ct = suppressWarnings(as.numeric(q_pcr_actb_ct)),
            q_pcr_ercc_ct = q_pcr_ercc_ct) %>%
  set_names(
    if_else(names(.) == "mirvie_id", names(.), paste0("meta_", names(.)))
  )
raw_counts <- collect_counts(here("inst", "extdata", "raw-counts", "MS")) %>%
  data.frame(row.names = "gene") %>%
  t() %>%
  as_tibble(rownames = "mirvie_id")
checkmate::assert_character(raw_counts$mirvie_id, unique = TRUE)
write_feather(raw_counts,
              here("inst", "extdata", "feathers", "MS_raw_counts.feather"),
              compression = "uncompressed")
outlier_df <- create_pca_outlier_df(metadata = metadata,
                                    raw_counts = raw_counts)
metadata <- left_join(metadata, outlier_df, by = c("mirvie_id" = "mirvie_id"))
checkmate::assert_character(metadata$mirvie_id, unique = TRUE)
write_feather(metadata, here("inst", "extdata", "feathers", "MS_meta.feather"),
              compression = "uncompressed")


# OT ---------------------------------------------------------------------------
metadata <- path(
  "/Volumes/GoogleDrive/Shared drives/MirvieData",
  "DataSeq/Cohorts/metadata/018_OT/201215_018_OT_metadata_CURATED.csv"
) %>%
  read_csv(col_types = cols()) %>%
  transmute(mirvie_id = as.character(mirvie_id),
            batch_num = as.integer(batch_number),
            mom_id = as.character(mom_id),
            collectionga = collectionga,
            sample_volume_ul = sample_volume_ul,
            q_pcr_actb_ct = suppressWarnings(as.numeric(q_pcr_actb_ct)),
            q_pcr_ercc_ct = q_pcr_ercc_ct) %>%
  set_names(
    if_else(names(.) == "mirvie_id", names(.), paste0("meta_", names(.)))
  )
raw_counts <- collect_counts(here("inst", "extdata", "raw-counts", "OT")) %>%
  data.frame(row.names = "gene") %>%
  t() %>%
  as_tibble(rownames = "mirvie_id")
checkmate::assert_character(raw_counts$mirvie_id, unique = TRUE)
write_feather(raw_counts,
              here("inst", "extdata", "feathers", "OT_raw_counts.feather"),
              compression = "uncompressed")
outlier_df <- create_pca_outlier_df(metadata = metadata,
                                    raw_counts = raw_counts)
metadata <- left_join(metadata, outlier_df, by = c("mirvie_id" = "mirvie_id"))
checkmate::assert_character(metadata$mirvie_id, unique = TRUE)
write_feather(metadata, here("inst", "extdata", "feathers", "OT_meta.feather"),
              compression = "uncompressed")


# PEMBA ------------------------------------------------------------------------
metadata <- path(
  "/Volumes/GoogleDrive/Shared drives/MirvieData",
  "DataSeq/Cohorts/metadata/008_PM/191001_PM_PTB_metadata_CURATED.csv"
) %>%
  read_csv(col_types = cols()) %>%
  transmute(mirvie_id = as.character(mirvie_id),
            collectionga = collectionga,
            deliveryga = deliveryga,
            weeks_to_delivery = time_to_deliv,
            sample_type = factor(sample_study_type),
            major_race = create_race_factor(tolower(major_race)),
            ethnicity = factor(ethnicity),
            iugr = is_iugr,
            sga = is_sga,
            ivf = is_ivf,
            chronic_hypertension = is_m_chronic_hypertension,
            lupus = is_m_lupus,
            caesarean = is_delivery_ceasarean,
            stillbirth = is_stillbirth,
            pre_eclampsia = is_m_pre_eclampsia,
            smoker = is_m_smoker,
            education = factor(m_education),
            mom_bmi = m_bmi,
            multiples = is_multiples,
            labor_spontaneous = is_labor_spontaneous,
            labor_augmented = is_labor_augmented,
            mom_id = as.character(mom_id),
            baby_sex = baby_gender,
            baby_weight_g = baby_weight_g,
            batch_num = as.integer(batch_number),
            sample_volume_ul = sample_volume_ul,
            q_pcr_actb_ct = q_pcr_actb_ct,
            q_pcr_ercc_ct = q_pcr_ercc_ct) %>%
  set_names(
    if_else(names(.) == "mirvie_id", names(.), paste0("meta_", names(.)))
  )
raw_counts <- collect_counts(here("inst", "extdata", "raw-counts", "PM")) %>%
  data.frame(row.names = "gene") %>%
  t() %>%
  as_tibble(rownames = "mirvie_id")
checkmate::assert_character(raw_counts$mirvie_id, unique = TRUE)
write_feather(raw_counts,
              here("inst", "extdata", "feathers", "PM_raw_counts.feather"),
              compression = "uncompressed")
outlier_df <- create_pca_outlier_df(metadata = metadata,
                                    raw_counts = raw_counts)
metadata <- left_join(metadata, outlier_df, by = c("mirvie_id" = "mirvie_id"))
checkmate::assert_character(metadata$mirvie_id, unique = TRUE)
write_feather(metadata, here("inst", "extdata", "feathers", "PM_meta.feather"),
              compression = "uncompressed")


# Pitts Imminent delivery ------------------------------------------------------
metadata <- read_csv(
  path("/Volumes/GoogleDrive/Shared drives/MirvieData",
       "DataSeq/Cohorts/metadata/015_PI/210112_015_PI_metadata_CURATED.csv"),
  col_types = cols()
) %>%
  transmute(mirvie_id = mirvie_id,
            mom_id = mom_id,
            draw = collection_num,
            major_race = factor(major_race,
                                levels = c("afro_american", "asian",
                                           "non_black_hispanic", "white",
                                           "unknown")
            ),
            #mom_weight_kg = conv_unit(preprgwt, "lbs", "kg"),
            #mom_height_cm = conv_unit(hgtininch, "inch", "cm"),
            #mom_bmi = m_bmi,
            #former_smoker = if_else(is_m_former_smoker == "nodata",
            #                        NA_character_, is_m_former_smoker),
            #mom_age = m_age,
            #parity = m_parity,
            baby_sex = baby_sex,
            baby_weight_g = baby_weight_g,
            #min_before_spin = min_before_spin,
            collectionga = collectionga,
            deliveryga = deliveryga,
            weeks_to_delivery = abs(time_to_deliv),
            q_pcr_actb_ct = q_pcr_actb_ct,
            q_pcr_ercc_ct = q_pcr_ercc_ct) %>%
  set_names(
    if_else(names(.) == "mirvie_id", names(.), paste0("meta_", names(.)))
  ) %>%
  mutate(mirvie_id = as.character(mirvie_id))

raw_counts <- collect_counts(here("inst", "extdata", "raw-counts", "PI")) %>%
  data.frame(row.names = "gene") %>%
  t() %>%
  as_tibble(rownames = "mirvie_id")
checkmate::assert_character(raw_counts$mirvie_id, unique = TRUE)
write_feather(raw_counts,
              here("inst", "extdata", "feathers", "PI_raw_counts.feather"),
              compression = "uncompressed")
outlier_df <- create_pca_outlier_df(metadata = metadata,
                                    raw_counts = raw_counts)
metadata <- left_join(metadata, outlier_df, by = c("mirvie_id" = "mirvie_id"))
checkmate::assert_character(metadata$mirvie_id, unique = TRUE)
write_feather(metadata, here("inst", "extdata", "feathers", "PI_meta.feather"),
              compression = "uncompressed")


# Pittsburgh -------------------------------------------------------------------
metadata <- read_csv(
  path("/Volumes/GoogleDrive/Shared drives/MirvieData",
       "DataSeq/Cohorts/metadata/010_PT/210112_pitt_dd_metadata_CURATED.csv"),
  col_types = cols()
) %>%
  filter(!is.na(mirvie_id)) %>%
  transmute(mirvie_id = as.character(mirvie_id),
            mom_id = as.character(mom_id),
            draw = as.double(collection_num),
            major_race = create_race_factor(major_race),
            mom_weight_kg = conv_unit(preprgwt, "lbs", "kg"),
            mom_height_cm = conv_unit(hgtininch, "inch", "cm"),
            mom_bmi = m_bmi,
            former_smoker = if_else(is_m_former_smoker == "nodata",
                                    NA_character_, is_m_former_smoker),
            mom_age = m_age,
            parity = m_parity,
            baby_sex = baby_sex,
            baby_weight_g = baby_weight_g,
            min_before_spin = min_before_spin,
            collectionga = collectionga,
            deliveryga = deliveryga,
            weeks_to_delivery = abs(time_to_deliv),
            q_pcr_actb_ct = q_pcr_actb_ct,
            q_pcr_ercc_ct = q_pcr_ercc_ct) %>%
  set_names(
    if_else(names(.) == "mirvie_id", names(.), paste0("meta_", names(.)))
  )
raw_count_dir <- here("inst", "extdata", "raw-counts", "PT")
recap_count_files <- dir_ls(raw_count_dir, regexp = "-Re-Cap")
file_move(recap_count_files, str_replace(recap_count_files, "-Re-Cap", ""))
raw_counts <- collect_counts(here("inst", "extdata", "raw-counts", "PT")) %>%
  data.frame(row.names = "gene") %>%
  t() %>%
  as_tibble(rownames = "mirvie_id")
checkmate::assert_character(raw_counts$mirvie_id, unique = TRUE)
write_feather(raw_counts,
              here("inst", "extdata", "feathers", "PT_raw_counts.feather"),
              compression = "uncompressed")
outlier_df <- create_pca_outlier_df(metadata = metadata,
                                    raw_counts = raw_counts)
metadata <- left_join(metadata, outlier_df, by = c("mirvie_id" = "mirvie_id"))
checkmate::assert_character(metadata$mirvie_id, unique = TRUE)
write_feather(metadata, here("inst", "extdata", "feathers", "PT_meta.feather"),
              compression = "uncompressed")


# Pitts Four -------------------------------------------------------------------
metadata <- read_csv(
  path("/Volumes/GoogleDrive/Shared drives/MirvieData",
       "DataSeq/Cohorts/metadata/019_PF/210125_019_PF_metadata_CURATED.csv"),
  col_types = cols()
) %>%
  transmute(mirvie_id = mirvie_id,
            batch_num = as.integer(batch_number),
            collectionga = collectionga,
            deliveryga = deliveryga,
            weeks_to_delivery = abs(time_to_deliv),
            sample_type = factor(sample_study_type),
            study_purpose = factor(primary_study_purpose),
            mom_id = mom_id,
            case_control_match_id = as.character(case_control_match_id),
            gravida = m_gravida,
            parity = m_parity,
            mom_bmi = suppressWarnings(as.numeric(m_bmi)),
            mom_age = m_age,
            pre_eclampsia = is_m_pre_eclampsia,
            sample_volume_ul = sample_volume_ul,
            q_pcr_actb_ct = q_pcr_actb_ct,
            q_pcr_ercc_ct = q_pcr_ercc_ct) %>%
  filter(!is.na(mirvie_id)) %>%
  set_names(
    if_else(names(.) == "mirvie_id", names(.), paste0("meta_", names(.)))
  )
raw_counts <- collect_counts(here("inst", "extdata", "raw-counts", "PF")) %>%
  data.frame(row.names = "gene") %>%
  t() %>%
  as_tibble(rownames = "mirvie_id")
checkmate::assert_character(raw_counts$mirvie_id, unique = TRUE)
write_feather(raw_counts,
              here("inst", "extdata", "feathers", "PF_raw_counts.feather"),
              compression = "uncompressed")
outlier_df <- create_pca_outlier_df(metadata = metadata,
                                    raw_counts = raw_counts)
metadata <- left_join(metadata, outlier_df, by = c("mirvie_id" = "mirvie_id"))
checkmate::assert_character(metadata$mirvie_id, unique = TRUE)
write_feather(metadata, here("inst", "extdata", "feathers", "PF_meta.feather"),
              compression = "uncompressed")


# Roskilde ---------------------------------------------------------------------
metadata <- read_csv(
  path("/Volumes/GoogleDrive/Shared drives/MirvieData",
       "DataSeq/Cohorts/metadata/007_RS/200901_007_RS_metadata_CURATED.csv"),
  col_types = cols()
) %>%
  transmute(mirvie_id = as.character(mirvie_id),
            mom_id = as.character(mom_id),
            draw = suppressWarnings(as.double(draw)),
            collectionga = as.numeric(collectionga),
            deliveryga = deliveryga,
            weeks_to_delivery = deliveryga - collectionga,
            major_race = create_race_factor("white"),
            smoker = case_when(
              is_m_smokes == "yes" ~ TRUE,
              is_m_smokes == "no" ~ FALSE,
              TRUE ~ NA
            ),
            conception_spontaneous = is_conception_spontaneous,
            conception_assisted = is_conception_assisted,
            ivf = is_ivf,
            mom_weight_kg = m_weight_kg,
            mom_height_cm = m_height_cm,
            mom_bmi = m_bmi,
            parity = m_parity,
            baby_sex = baby_sex,
            baby_weight_g = map_dbl(
              baby_weight_g,
              ~mean(strex::str_extract_numbers(.)[[1]])
            ),
            baby_head_circumference_cm = map_dbl(
              baby_head_circumference_cm,
              ~mean(strex::str_extract_numbers(.)[[1]])
            ),
            baby_length_cm = map_dbl(
              baby_length_cm,
              ~mean(strex::str_extract_numbers(.)[[1]])
            ),
            labor_spontaneous = is_labor_spontaneous,
            labor_augmented = is_labor_augmented,
            q_pcr_actb_ct = q_pcr_actb_ct,
            q_pcr_ercc_ct = q_pcr_ercc_ct) %>%
  set_names(
    if_else(names(.) == "mirvie_id", names(.), paste0("meta_", names(.)))
  )
raw_counts <- collect_counts(here("inst", "extdata", "raw-counts", "RS")) %>%
  data.frame(row.names = "gene") %>%
  t() %>%
  as_tibble(rownames = "mirvie_id")
checkmate::assert_character(raw_counts$mirvie_id, unique = TRUE)
write_feather(raw_counts,
              here("inst", "extdata", "feathers", "RS_raw_counts.feather"),
              compression = "uncompressed")
outlier_df <- create_pca_outlier_df(metadata = metadata,
                                    raw_counts = raw_counts)
metadata <- left_join(metadata, outlier_df, by = c("mirvie_id" = "mirvie_id"))
checkmate::assert_character(metadata$mirvie_id, unique = TRUE)
write_feather(metadata, here("inst", "extdata", "feathers", "RS_meta.feather"),
              compression = "uncompressed")


# Stanford ---------------------------------------------------------------------
metadata <- read_csv(
  path("/Volumes/GoogleDrive/Shared drives/MirvieData",
       "DataSeq/Cohorts/metadata/002_ST/ST_CuratedMetadata.csv"),
  col_types = cols()
) %>%
  janitor::clean_names() %>%
  transmute(mirvie_id = as.character(mirvie_id),
            collectionga = collectionga,
            deliveryga = deliveryga,
            weeks_to_delivery = deliveryga - collectionga,
            pre_eclampsia = str_detect(other, "[Pp]re.*eclampsia")
  ) %>%
  replace_na(list(pre_eclampsia = FALSE)) %>%
  set_names(
    if_else(names(.) == "mirvie_id", names(.), paste0("meta_", names(.)))
  )
raw_counts <- collect_counts(here("inst", "extdata", "raw-counts", "ST")) %>%
  data.frame(row.names = "gene") %>%
  t() %>%
  as_tibble(rownames = "mirvie_id")
checkmate::assert_character(raw_counts$mirvie_id, unique = TRUE)
write_feather(raw_counts,
              here("inst", "extdata", "feathers", "ST_raw_counts.feather"),
              compression = "uncompressed")
outlier_df <- create_pca_outlier_df(metadata = metadata,
                                    raw_counts = raw_counts)
metadata <- left_join(metadata, outlier_df, by = c("mirvie_id" = "mirvie_id"))
checkmate::assert_character(metadata$mirvie_id, unique = TRUE)
write_feather(metadata, here("inst", "extdata", "feathers", "ST_meta.feather"),
              compression = "uncompressed")


# UPenn ------------------------------------------------------------------------
metadata <- read_csv(here("inst", "extdata", "raw-counts", "UP",
                          "190919_UPenn_metadata.csv"),
                     col_types = cols())
up_mirvie_ids <- set_names(metadata$UNiqueID, metadata$mirvie_id)
metadata <- metadata %>%
  select(-mirvie_id) %>%
  rename(mirvie_id = UNiqueID, delivery_type = DeliveryType) %>%
  select(mirvie_id, collectionga, deliveryga) %>%
  set_names(
    if_else(names(.) == "mirvie_id", names(.), paste0("meta_", names(.)))
  )
raw_counts <- read_tsv(here("inst", "extdata", "raw-counts", "UP",
                            "UPenn_genes_counts.txt"),
                       col_types = cols()) %>%
  mirviemisc:::clean_ccs(convert_genenames = TRUE,
                         remove_ercc = TRUE,
                         remove_rp_4_11 = TRUE,
                         remove_metadata = TRUE) %>%
  data.frame(row.names = "gene") %>%
  t() %>%
  as_tibble(rownames = "mirvie_id") %>%
  mutate(mirvie_id = up_mirvie_ids[mirvie_id])
checkmate::assert_character(raw_counts$mirvie_id, unique = TRUE)
write_feather(raw_counts,
              here("inst", "extdata", "feathers", "UP_raw_counts.feather"),
              version = 1)
outlier_df <- create_pca_outlier_df(metadata = metadata,
                                    raw_counts = raw_counts)
metadata <- left_join(metadata, outlier_df, by = c("mirvie_id" = "mirvie_id"))
checkmate::assert_character(metadata$mirvie_id, unique = TRUE)
write_feather(metadata, here("inst", "extdata", "feathers", "UP_meta.feather"),
              compression = "uncompressed")


# DTPR -------------------------------------------------------------------------
metadata <- suppressWarnings(
  path(
    "~/Downloads/20200825_Sample Tracking Sheet_DTPr - Extraction.csv"
  ) %>%
    read_csv(skip = 2, col_types = cols()) %>%
    transmute(mirvie_id = `Internal Barcode`,
              meta_collectionga = as.numeric(GA))
)
raw_counts <- collect_counts(here("inst", "extdata", "raw-counts", "DP")) %>%
  data.frame(row.names = "gene") %>%
  t() %>%
  as_tibble(rownames = "mirvie_id")
checkmate::assert_character(raw_counts$mirvie_id, unique = TRUE)
write_feather(raw_counts,
              here("inst", "extdata", "feathers", "DP_raw_counts.feather"),
              compression = "uncompressed")
outlier_df <- create_pca_outlier_df(metadata = metadata,
                                    raw_counts = raw_counts)
metadata <- left_join(metadata, outlier_df, by = c("mirvie_id" = "mirvie_id"))
checkmate::assert_character(metadata$mirvie_id, unique = TRUE)
write_feather(metadata, here("inst", "extdata", "feathers", "DP_meta.feather"),
              compression = "uncompressed")
