## ----knitr-setup, include = FALSE---------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  message = FALSE, warning = FALSE,
  fig.width = 5, fig.height = 5, dpi = 222,
  out.width = "70%", out.height = "70%"
)

## ----setup--------------------------------------------------------------------
pacman::p_load(rsample, dplyr, ggplot2, mirmodels)
set.seed(1)
data <- get_combined_cohort_data(c("OT", "GA", "MS", "RS", "PT"),
                                 log2 = TRUE, tot_counts = TRUE) %>% 
  sample_frac()
data_split <- initial_split(data, strata = meta_collectionga, prop = 0.80)

## ----basic-pre----------------------------------------------------------------
mod <- MASS::rlm(ACTB ~ log2_tot_counts, data = training(data_split))
ggplot(training(data_split), aes(log2_tot_counts, ACTB)) + 
  geom_point() + 
  geom_abline(intercept = coef(mod)[1], slope = coef(mod)[2], color = "blue") +
  xlim(10, 25) + ylim(0, 20) + ggtitle("Uncorrected training data")
ggplot(testing(data_split), aes(log2_tot_counts, ACTB)) + 
  geom_point() +
  geom_abline(intercept = coef(mod)[1], slope = coef(mod)[2], 
              color = "blue", linetype = "dashed") +
  xlim(10, 25) + ylim(0, 20) + ggtitle("Uncorrected testing data")

## ----basic--------------------------------------------------------------------
data_corr <- linear_correct(training_data = training(data_split),
                            testing_data = testing(data_split),
                            correct_cols = "ACTB",
                            correct_for_cols = "log2_tot_counts")
ggplot(data_corr$training_data, aes(log2_tot_counts, ACTB)) + 
  geom_point() + 
  geom_hline(yintercept = median(testing(data_split)$ACTB), color = "blue") + 
  xlim(10, 25) + ylim(0, 20) + ggtitle("Corrected training data")
ggplot(data_corr$testing_data, aes(log2_tot_counts, ACTB)) + 
  geom_point() + 
  geom_hline(yintercept = median(testing(data_split)$ACTB), 
             color = "blue", linetype = "dashed") + 
  xlim(10, 25) + ylim(0, 20) + ggtitle("Corrected testing data")

## ----CAPN6-plot---------------------------------------------------------------
ggplot(training(data_split), aes(meta_collectionga, CAPN6, color = cohort)) +
  geom_smooth(aes(meta_collectionga, CAPN6, color = NULL), 
              method = MASS::rlm, se = FALSE) +
  geom_point() + ggthemes::scale_color_colorblind() +
  xlab("Gestational age (weeks)")

## ----CAPN6-naive--------------------------------------------------------------
data_corr <- linear_correct(training_data = training(data_split),
                            testing_data = testing(data_split),
                            correct_cols = "CAPN6",
                            correct_for_cols = "cohort")
ggplot(data_corr$training_data, aes(meta_collectionga, CAPN6, color = cohort)) +
  geom_point() + ggthemes::scale_color_colorblind() +
  xlab("Gestational age (weeks)")

## ----CAPN6-plot-again---------------------------------------------------------
ggplot(training(data_split), aes(meta_collectionga, CAPN6, color = cohort)) +
  geom_smooth(aes(meta_collectionga, CAPN6, color = NULL), 
              method = MASS::rlm, se = FALSE) +
  geom_point() + ggthemes::scale_color_colorblind() +
  xlab("Gestational age (weeks)") +
  ggtitle("Raw training data", "Gestational age effect present")

## ----CAPN6-ga-removed-plot----------------------------------------------------
data_corr_intermediate = linear_correct(training_data = training(data_split),
                                        correct_cols = "CAPN6",
                                        correct_for_cols = "meta_collectionga")
ggplot(data_corr_intermediate$training_data,
       aes(meta_collectionga, CAPN6, color = cohort)) +
  geom_hline(yintercept = median(training(data_split)$CAPN6), color = "blue") +
  geom_point() + ggthemes::scale_color_colorblind() +
  xlab("Gestational age (weeks)") +
  ggtitle("Training data", "Gestational age effect removed")

## ----cohort-mod-GA-removed----------------------------------------------------
mod <- MASS::rlm(CAPN6 ~ cohort, data = data_corr_intermediate$training_data)
coef(mod)

## ----glorious-correct---------------------------------------------------------
data_corr <- linear_correct(training_data = training(data_split),
                            testing_data = testing(data_split),
                            correct_cols = "CAPN6",
                            correct_for_cols = "cohort",
                            keep_effect_cols = "meta_collectionga")
ggplot(data_corr$training_data, aes(meta_collectionga, CAPN6, color = cohort)) +
  geom_point() + ggthemes::scale_color_colorblind() +
  xlab("Gestational age (weeks)") +
  ggtitle("Corrected training data")
ggplot(data_corr$testing_data, aes(meta_collectionga, CAPN6, color = cohort)) +
  geom_point() + ggthemes::scale_color_colorblind() +
  xlab("Gestational age (weeks)") +
  ggtitle("Corrected testing data")

## ----glorious-correct-include-counts------------------------------------------
data_corr <- linear_correct(training_data = training(data_split),
                            testing_data = testing(data_split),
                            correct_cols = "CAPN6",
                            correct_for_cols = c("cohort", "log2_tot_counts"),
                            keep_effect_cols = "meta_collectionga")
ggplot(data_corr$training_data, aes(meta_collectionga, CAPN6, color = cohort)) +
  geom_point() + ggthemes::scale_color_colorblind() +
  xlab("Gestational age (weeks)") +
  ggtitle("Corrected training data")
ggplot(data_corr$testing_data, aes(meta_collectionga, CAPN6, color = cohort)) +
  geom_point() + ggthemes::scale_color_colorblind() +
  xlab("Gestational age (weeks)") +
  ggtitle("Corrected testing data")

