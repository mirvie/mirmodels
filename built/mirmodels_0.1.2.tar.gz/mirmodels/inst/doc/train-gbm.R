## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
pacman::p_load(tidyverse, rsample, workflows, parsnip, yardstick, 
               mirmodels)
iris_data <- janitor::clean_names(datasets::iris)
dim(iris_data)
names(iris_data)

## ----tts----------------------------------------------------------------------
set.seed(1)
iris_data_split <- initial_split(iris_data, prop = 2/3, strata = "species")
iris_data_training <- training(iris_data_split)
iris_data_testing <- testing(iris_data_split)

## ----train, warning=FALSE, message=FALSE--------------------------------------
mod <- train_gbm(
  training_data = iris_data_training,
  outcome = "species",
  metric = "mn_log_loss",
  hyper_param_grid = list(trees = c(25, 50, 100),
                          tree_depth = 1:2,
                          learn_rate = c(0.1, 0.01)),
  strata = "species",
  selection_method = "Breiman",
  simplicity_params = c("trees"),
  n_cores = 5
)

## ----peer---------------------------------------------------------------------
pull_workflow_fit(mod)

## ----peer-get-info, include=FALSE---------------------------------------------
peer_string <- capture.output(print(pull_workflow_fit(mod))) %>% 
  paste(collapse = " ")
nrounds <- strex::str_first_number_after_first(peer_string, "nrounds")
max_depth <- strex::str_first_number_after_first(peer_string, "max_depth")
eta <- strex::str_first_number_after_first(peer_string, "eta", decimals = TRUE)

## ----test, warning=FALSE------------------------------------------------------
preds_abs <- predict(mod, new_data = iris_data_testing)
preds_prob <- predict(mod, new_data = iris_data_testing, type = "prob")
truth <- iris_data_testing$species
accuracy_vec(truth, preds_abs[[1]])
mn_log_loss_vec(truth, as.matrix(preds_prob))

## -----------------------------------------------------------------------------
correct_preds <- preds_abs[[1]] == truth
mean(apply(preds_prob[correct_preds, ], 1, max))
mean(apply(preds_prob[!correct_preds, ], 1, max))

## ----vip1, warning=FALSE------------------------------------------------------
vimp(mod)

## ----numeric-outcome----------------------------------------------------------
iris_data_split <- initial_split(iris_data, prop = 2/3, 
                                 strata = "petal_length")
iris_data_training <- training(iris_data_split)
iris_data_testing <- testing(iris_data_split)
mod <- train_gbm(
  training_data = iris_data_training,
  outcome = "petal_length",
  metric = "rmse",
  hyper_param_grid = list(trees = c(25, 50, 100),
                          tree_depth = 1:2,
                          learn_rate = c(0.1, 0.01)),
  strata = "petal_length",
  selection_method = "Breiman",
  simplicity_params = c("trees"),
  n_cores = 5
)
preds <- predict(mod, new_data = iris_data_testing)
truth <- iris_data_testing$petal_length
rmse_vec(truth, preds[[1]])
vimp(mod)

