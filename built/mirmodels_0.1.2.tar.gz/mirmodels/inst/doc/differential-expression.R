## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7, fig.height = 5
)

## ----setup--------------------------------------------------------------------
pacman::p_load(mirmodels, tidyverse)

## ----PAPPA2-------------------------------------------------------------------
ms_data <- get_ms_data() %>% 
  filter(!is.na(meta_pre_eclampsia))
ggplot(ms_data, aes(meta_pre_eclampsia, PAPPA2)) +
  geom_boxplot(outlier.alpha = 0) + geom_jitter(height = 0)

## ----deseq--------------------------------------------------------------------
de_result <- deseq(ms_data, condition = "meta_pre_eclampsia", n_cores = 5)
head(de_result)
filter(de_result, gene == "PAPPA2")

## ----edger--------------------------------------------------------------------
de_result <- edger(ms_data, condition = "meta_pre_eclampsia")
head(de_result)
filter(de_result, gene == "PAPPA2")

## ----spearman-----------------------------------------------------------------
de_result <- cor_de(ms_data, condition = "meta_pre_eclampsia",
                    method = "spearman")
head(de_result)
filter(de_result, gene == "PAPPA2")

## ----kendall------------------------------------------------------------------
de_result <- cor_de(ms_data, condition = "meta_pre_eclampsia",
                    method = "kendall")
head(de_result)
filter(de_result, gene == "PAPPA2")

## ----pearson------------------------------------------------------------------
de_result <- cor_de(ms_data, condition = "meta_pre_eclampsia",
                    method = "pearson")
head(de_result)
filter(de_result, gene == "PAPPA2")

