
<!-- README.md is generated from README.Rmd. Please edit that file -->

# mirmodels

<!-- badges: start -->
<!-- badges: end -->

## Installation

1.  In R, run

        install.packages("BiocManager", repo = "https://cran.rstudio.com/") 

2.  In R, run

        BiocManager::install(c("arrow", "BiocParallel", "broom", "car", 
                              "checkmate", "clipr", "DescTools", "DESeq2", 
                              "dials", "doFuture", "doParallel", "dplyr", 
                              "edgeR", "embed", "forcats", "foreach", "fs", 
                              "furrr", "future", "generics", "ggplot2", 
                              "ggpmisc", "ggrepel", "ggthemes", "glmnet", 
                              "glue", "janitor", "knitr", "magrittr", "MASS", 
                              "matrixStats", "mirmisc", "mlbench", "mockery", 
                              "pacman", "parsnip", "pROC", "purrr", 
                              "RcppRoll", "readr", "recipes", "rlang", 
                              "rmarkdown", "rrcov", "rsample", "scales", 
                              "spelling", "strex", "stringr", "testthat", 
                              "tibble", "tidyr", "tune", "usethis", "vip", 
                              "withr", "workflows", "xgboost", "yardstick", 
                              "zoo")) 

3.  The tar.gz files are at `built/mirmodels_x.x.x.tar.gz`. At the
    command line, enter

    ``` commandline
    R CMD INSTALL {path-to-latest-targz-file}
    ```

## Documentation

See the `pkgdown` site at <https://mirvie.gitlab.io/mirmodels/>.
