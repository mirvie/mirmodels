#' @importFrom utils globalVariables
#' @importFrom magrittr '%T>%'
#' @importFrom xgboost xgb.gblinear.history
#' @importFrom rlang '%||%' ':='
NULL


## quiets concerns of R CMD check due to tidy evaluation
if (getRversion() >= "2.15.1") {
  globalVariables(c(".", ".x", ".y", ".data"))
}
