#' `r roxy_cohort_data_title("Brigham and Women's Hospital")`
#'
#' `r roxy_cohort_data_subtitle("Brigham and Women's Hospital")`
#'
#' `r roxy_meta_collectionga()`
#' `r roxy_meta_deliveryga()`
#' `r roxy_meta_weeks_to_delivery()`
#' `r roxy_meta_sample_type()`
#' `r roxy_meta_study_purpose()` Pre-eclampsia or preterm birth.
#' `r roxy_meta_major_race()`
#' `r roxy_meta_mom_id()`
#' `r roxy_meta_collection_num()`
#' `r roxy_meta_case_control_match_id()`
#' `r roxy_meta_min_before_spin()`
#' `r roxy_meta_mom_age()`
#' `r roxy_meta_mom_bmi()`
#' `r roxy_meta_sga()`
#' `r roxy_meta_pre_eclampsia()`
#' `r roxy_meta_baby_weight_g()`
#' `r roxy_meta_batch_num()`
#' `r roxy_meta_sample_volume_ul()`
#' `r roxy_meta_q_pcr_actb_ct()`
#' `r roxy_meta_q_pcr_ercc_ct()`
#' `r roxy_meta_q_pcr_ver()`
#' `r roxy_meta_lab_qc_passed()`
#' `r roxy_meta_pca_outlier()`
#'
#' `r roxy_cohort_data_details()`
#'
#' @inheritParams get_ga_data
#'
#' @family cohort data
#'
#' @export
get_bw_data <- function(cpm = FALSE, log2 = FALSE, tot_counts = FALSE,
                        remove_bads = TRUE,
                        remove_noncoding = TRUE, remove_pseudo = TRUE,
                        gene_predicate = NULL,
                        feather_dir = NULL) {
  checkmate::assert_flag(remove_bads)
  out <- get_cohort_data("bw",
                         cpm = cpm, log2 = log2, tot_counts = tot_counts,
                         remove_bads = remove_bads, 
                         remove_noncoding = remove_noncoding, 
                         remove_pseudo = remove_pseudo,
                         gene_predicate = gene_predicate,
                         feather_dir = feather_dir
  )
  out
}

#' `r roxy_cohort_data_title("DTPR")`
#'
#' `r roxy_cohort_data_subtitle("DTPR")`
#'
#' `r roxy_meta_collectionga()`
#'
#' `r roxy_cohort_data_details()`
#'
#' @inheritParams get_ga_data
#'
#' @family cohort data
#'
#' @export
get_dp_data <- function(cpm = FALSE, log2 = FALSE, tot_counts = FALSE,
                        remove_bads = TRUE,
                        remove_noncoding = TRUE, remove_pseudo = TRUE,
                        gene_predicate = NULL,
                        feather_dir = NULL) {
  checkmate::assert_flag(remove_bads)
  out <- get_cohort_data("dp",
                         cpm = cpm, log2 = log2, tot_counts = tot_counts,
                         remove_bads = remove_bads, 
                         remove_noncoding = remove_noncoding, 
                         remove_pseudo = remove_pseudo,
                         gene_predicate = gene_predicate,
                         feather_dir = feather_dir
  )
  out
}

#' `r roxy_cohort_data_title("GAPPS")`
#'
#' `r roxy_cohort_data_subtitle("GAPPS")`
#'
#' `r roxy_meta_mom_id()`
#' `r roxy_meta_major_race()`
#' `r roxy_meta_ethnicity()`
#' `r roxy_meta_mom_age()`
#' `r roxy_meta_deliveryga()`
#' `r roxy_meta_parity()`
#' `r roxy_meta_prom()`
#' `r roxy_meta_pprom()`
#' `r roxy_meta_iugr()`
#' `r roxy_meta_pre_eclampsia()`
#' `r roxy_meta_smoker()`
#' `r roxy_meta_labor_spontaneous()`
#' `r roxy_meta_labor_augmented()`
#' `r roxy_meta_labor_induced_complication()`
#' `r roxy_meta_labor_induced_elective()`
#' `r roxy_meta_ivf()`
#' `r roxy_meta_chronic_hypertension()`
#' `r roxy_meta_collectionga()`
#' `r roxy_meta_min_before_spin()`
#' `r roxy_meta_n_prior_term_deliveries()`
#' `r roxy_meta_n_prior_preterm_deliveries()`
#' `r roxy_meta_baby_sex()`
#' `r roxy_meta_baby_weight_g()`
#' `r roxy_meta_weeks_to_delivery()`
#' `r roxy_meta_sample_volume_ul()`
#' `r roxy_meta_q_pcr_actb_ct()`
#' `r roxy_meta_q_pcr_ercc_ct()`
#' `r roxy_meta_pca_outlier()`
#'
#' `r roxy_cohort_data_details()`
#'
#' This contains samples from the GA, PG (preterm GAPPS) and VG (validation
#' GAPPS) cohorts.
#'
#' @param cpm A flag. Gene counts in counts per million?
#' @param log2 A flag. Gene counts on log2 scale? If both `cpm` and `log2` are
#'   `TRUE`, then the `log2` calculation comes after the `cpm` calculation. The
#'   transformation actually used is `x <- log2(x + 1)`.
#' @param tot_counts A flag. Add a column for the total number of counts for
#'   this sample? If `log2 = TRUE`, a column `log2_tot_counts` will also be
#'   added with `log2_tot_counts = log2(tot_counts + 1)`.
#' @param remove_bads A flag. Remove samples that have been flagged as bad for
#'   whatever reason. The default is to do so.
#' @param remove_noncoding A flag. Remove non-coding genes?
#' @param remove_pseudo A flag. Remove psuedogenes?
#' @param gene_predicate A predicate function which takes a single numeric
#'   argument. Only gene columns returning `TRUE` will be in the output. This
#'   will be passed through [rlang::as_function()], so formula-style lambdas are
#'   permitted. For example, to keep only genes whose medians are positive, you
#'   can use `gene_predicate = function(x) {median(x) > 0}` or `gene_predicate =
#'   ~median(.) > 0`. This calculation is done in the transformed space, so if
#'   you select `cpm = FALSE, log2 = TRUE, gene_predicate = ~median(.) > 2`,
#'   you're actually selecting genes with medians greater than 4 in raw space
#'   (since `log2(4) == 2`).
#' @param feather_dir A string. The path to a directory containing feather
#'   files.
#'
#' @family cohort data
#'
#' @export
get_ga_data <- function(cpm = FALSE, log2 = FALSE, tot_counts = FALSE,
                        remove_bads = TRUE,
                        remove_noncoding = TRUE, remove_pseudo = TRUE,
                        gene_predicate = NULL,
                        feather_dir = NULL) {
  checkmate::assert_flag(remove_bads)
  out <- get_cohort_data("ga",
    cpm = cpm, log2 = log2, tot_counts = tot_counts,
    remove_bads = remove_bads, 
    remove_noncoding = remove_noncoding, remove_pseudo = remove_pseudo,
    gene_predicate = gene_predicate,
    feather_dir = feather_dir
  )
  out
}

#' `r roxy_cohort_data_title("Preterm GAPPS")`
#'
#' `r roxy_cohort_data_subtitle("Preterm GAPPS")`
#'
#' `r roxy_meta_major_race()`
#' `r roxy_meta_ethnicity()`
#' `r roxy_meta_deliveryga()`
#' `r roxy_meta_mom_age()`
#' `r roxy_meta_prom()`
#' `r roxy_meta_pprom()`
#' `r roxy_meta_normal_delivery()`
#' `r roxy_meta_caesarean()`
#' `r roxy_meta_smoker()`
#' `r roxy_meta_labor_spontaneous()`
#' `r roxy_meta_baby_sex()`
#' `r roxy_meta_collectionga()`
#' `r roxy_meta_weeks_to_delivery()`
#' `r roxy_meta_min_before_spin()`
#' `r roxy_meta_sample_volume_ul()`
#' `r roxy_meta_q_pcr_actb_ct()`
#' `r roxy_meta_q_pcr_ercc_ct()`
#' `r roxy_meta_pca_outlier()`
#'
#' `r roxy_cohort_data_details()`
#'
#' @inheritParams get_ga_data
#'
#' @family cohort data
#'
#' @export
get_pg_data <- function(cpm = FALSE, log2 = FALSE, tot_counts = FALSE,
                        remove_bads = TRUE,
                        remove_noncoding = TRUE, remove_pseudo = TRUE,
                        gene_predicate = NULL,
                        feather_dir = NULL) {
  checkmate::assert_flag(remove_bads)
  out <- get_cohort_data("pg",
                         cpm = cpm, log2 = log2, tot_counts = tot_counts,
                         remove_bads = remove_bads, 
                         remove_noncoding = remove_noncoding, 
                         remove_pseudo = remove_pseudo,
                         gene_predicate = gene_predicate,
                         feather_dir = feather_dir
  )
  out
}

#' `r roxy_cohort_data_title("Validation GAPPS")`
#'
#' `r roxy_cohort_data_subtitle("Validation GAPPS")`
#'
#' `r roxy_meta_mom_id()`
#' `r roxy_meta_major_race()`
#' `r roxy_meta_ethnicity()`
#' `r roxy_meta_mom_age()`
#' `r roxy_meta_collectionga()`
#' `r roxy_meta_deliveryga()`
#' `r roxy_meta_smoker()`
#' `r roxy_meta_labor_spontaneous()`
#' `r roxy_meta_baby_sex()`
#' `r roxy_meta_baby_weight_g()`
#' `r roxy_meta_weeks_to_delivery()`
#' `r roxy_meta_q_pcr_actb_ct()`
#' `r roxy_meta_q_pcr_ercc_ct()`
#' `r roxy_meta_pca_outlier()`
#'
#' `r roxy_cohort_data_details()`
#'
#' @inheritParams get_ga_data
#'
#' @family cohort data
#'
#' @export
get_vg_data <- function(cpm = FALSE, log2 = FALSE, tot_counts = FALSE,
                        remove_bads = TRUE,
                        remove_noncoding = TRUE, remove_pseudo = TRUE,
                        gene_predicate = NULL,
                        feather_dir = NULL) {
  checkmate::assert_flag(remove_bads)
  out <- get_cohort_data("vg",
                         cpm = cpm, log2 = log2, tot_counts = tot_counts,
                         remove_bads = remove_bads, 
                         remove_noncoding = remove_noncoding, 
                         remove_pseudo = remove_pseudo,
                         gene_predicate = gene_predicate,
                         feather_dir = feather_dir
  )
  out
}

#' `r roxy_cohort_data_title("Iowa")`
#'
#' `r roxy_cohort_data_subtitle("Iowa")`
#'
#' `r roxy_meta_mom_id()`
#' `r roxy_meta_sample_type()`
#' `r roxy_meta_major_race()`
#' `r roxy_meta_mom_bmi()`
#' `r roxy_meta_smoker()`
#' `r roxy_meta_pre_eclampsia()`
#' `r roxy_meta_parity()`
#' `r roxy_meta_labor_spontaneous()`
#' `r roxy_meta_baby_weight_g()`
#' `r roxy_meta_baby_length_cm()`
#' `r roxy_meta_stillbirth()`
#' `r roxy_meta_collectionga()`
#' `r roxy_meta_deliveryga()`
#' `r roxy_meta_weeks_to_delivery()`
#' `r roxy_meta_mom_age()`
#' `r roxy_meta_caesarean()`
#' `r roxy_meta_q_pcr_actb_ct()`
#' `r roxy_meta_q_pcr_ercc_ct()`
#' `r roxy_meta_pca_outlier()`
#'
#' `r roxy_cohort_data_details()`
#'
#' @inheritParams get_ga_data
#'
#' @family cohort data
#'
#' @export
get_io_data <- function(cpm = FALSE, log2 = FALSE, tot_counts = FALSE,
                        remove_bads = TRUE,
                        remove_noncoding = TRUE, remove_pseudo = TRUE,
                        gene_predicate = NULL,
                        feather_dir = NULL) {
  checkmate::assert_flag(remove_bads)
  out <- get_cohort_data("io",
                         cpm = cpm, log2 = log2, tot_counts = tot_counts,
                         remove_bads = remove_bads, 
                         remove_noncoding = remove_noncoding, 
                         remove_pseudo = remove_pseudo,
                         gene_predicate = gene_predicate,
                         feather_dir = feather_dir
  )
  out
}

#' `r roxy_cohort_data_title("King's College London")`
#'
#' `r roxy_cohort_data_subtitle("King's College London")`
#' 
#' `r roxy_meta_mom_id()`
#' `r roxy_meta_major_race()`
#' `r roxy_meta_sample_type()`
#' `r roxy_meta_case_control_match_id()`
#' `r roxy_meta_prev_pprom()`
#' `r roxy_meta_prev_late_miscarriage()`
#' `r roxy_meta_prev_cervical_surgery()`
#' `r roxy_meta_low_risk_at_enrollment()`
#' `r roxy_meta_type_2_diabetes()`
#' `r roxy_meta_autoimmune_disease()`
#' `r roxy_meta_chronic_viral_infection()`
#' `r roxy_meta_antihypertensives()`
#' `r roxy_meta_immunosuppressants()`
#' `r roxy_meta_mom_height_cm()`
#' `r roxy_meta_mom_weight_kg()`
#' `r roxy_meta_mom_bmi()`
#' `r roxy_meta_mom_age()`
#' `r roxy_meta_ethnicity()`
#' `r roxy_meta_bv_history()`
#' `r roxy_meta_smoker()` Levels are "current", "ex" and "never".
#' `r roxy_meta_first_pregnancy()`
#' `r roxy_meta_n_prior_preg_0_13()`
#' `r roxy_meta_n_prior_preg_14_23()`
#' `r roxy_meta_n_prior_preg_24_plus()`
#' `r roxy_meta_n_prior_preg_37_plus()`
#' `r roxy_meta_tocolysis()`
#' `r roxy_meta_steroids_fetal_lung()`
#' `r roxy_meta_antibiotics()`
#' `r roxy_meta_progesterone()`
#' `r roxy_meta_emergengy_cerclage()`
#' `r roxy_meta_mag_sulph()`
#' `r roxy_meta_maternal_pyrexia()`
#' `r roxy_meta_crp_highest_value()`
#' `r roxy_meta_wcc_highest_value()`
#' `r roxy_meta_blood_loss_ml()`
#' `r roxy_meta_threatened_preterm_labor()`
#' `r roxy_meta_pprom()`
#' `r roxy_meta_obstetric_cholestasis()`
#' `r roxy_meta_antepartum_haemorrhage()`
#' `r roxy_meta_vital_status()`
#' `r roxy_meta_miscarriage()`
#' `r roxy_meta_stillbirth()`
#' `r roxy_meta_baby_sex()`
#' `r roxy_meta_baby_weight_g()`
#' `r roxy_meta_apgar()`
#' `r roxy_meta_sbcu_or_nicu()`
#' `r roxy_meta_neonatal_inpatient_nights()`
#' `r roxy_meta_hrs_rom_to_delivery()`
#' `r roxy_meta_min_before_spin()`
#' `r roxy_meta_collectionga()`
#' `r roxy_meta_deliveryga()`
#' `r roxy_meta_weeks_to_delivery()`
#' `r roxy_meta_study_purpose()` IUGR, pre-eclampsia or preterm birth.
#' `r roxy_meta_mom_gdm()`
#' `r roxy_meta_pre_eclampsia()`
#' `r roxy_meta_chronic_hypertension()`
#' `r roxy_meta_mom_gbs()`
#' `r roxy_meta_non_gdm_diabetic()`
#' `r roxy_meta_normal_delivery()`
#' `r roxy_meta_labor_spontaneous()`
#' `r roxy_meta_n_prior_preterm_deliveries()`
#' `r roxy_meta_q_pcr_actb_ct()`
#' `r roxy_meta_q_pcr_ercc_ct()`
#' `r roxy_meta_q_pcr_ver()`
#' `r roxy_meta_lab_qc_passed()`
#' `r roxy_meta_pca_outlier()`
#'
#' `r roxy_cohort_data_details()`
#'
#' @inheritParams get_ga_data
#'
#' @family cohort data
#'
#' @export
get_kl_data <- function(cpm = FALSE, log2 = FALSE, tot_counts = FALSE,
                        remove_bads = TRUE,
                        remove_noncoding = TRUE, remove_pseudo = TRUE,
                        gene_predicate = NULL,
                        feather_dir = NULL) {
  checkmate::assert_flag(remove_bads)
  out <- get_cohort_data("kl",
                         cpm = cpm, log2 = log2, tot_counts = tot_counts,
                         remove_bads = remove_bads, 
                         remove_noncoding = remove_noncoding, 
                         remove_pseudo = remove_pseudo,
                         gene_predicate = gene_predicate,
                         feather_dir = feather_dir
  )
  out
}

#' `r roxy_cohort_data_title("Michigan State University")`
#'
#' `r roxy_cohort_data_subtitle("MSU")`
#'
#' `r roxy_meta_batch_num()`
#' `r roxy_meta_mom_id()`
#' `r roxy_meta_major_race()`
#' `r roxy_meta_sample_type()`
#' `r roxy_meta_case_control_match_id()`
#' `r roxy_meta_study_purpose()`
#' `r roxy_meta_collectionga()`
#' `r roxy_meta_deliveryga()`
#' `r roxy_meta_weeks_to_delivery()`
#' `r roxy_meta_education()`
#' `r roxy_meta_pe_htn()`
#' `r roxy_meta_gravida()`
#' `r roxy_meta_parity()`
#' `r roxy_meta_n_prior_term_deliveries()`
#' `r roxy_meta_n_prior_preterm_deliveries()`
#' `r roxy_meta_baby_weight_g()`
#' `r roxy_meta_prenatal_screening_ga()`
#' `r roxy_meta_mom_bmi()`
#' `r roxy_meta_mom_age()`
#' `r roxy_meta_baby_sex()`
#' `r roxy_meta_ga_method()`
#' `r roxy_meta_conception_assisted()`
#' `r roxy_meta_sga()`
#' `r roxy_meta_mom_gdm()`
#' `r roxy_meta_lupus()`
#' `r roxy_meta_chronic_hypertension()`
#' `r roxy_meta_pre_eclampsia()`
#' `r roxy_meta_antibiotics()`
#' `r roxy_meta_stillbirth()`
#' `r roxy_meta_caesarean()`
#' `r roxy_meta_pprom()`
#' `r roxy_meta_labor_spontaneous()`
#' `r roxy_meta_labor_induced_complication()`
#' `r roxy_meta_sample_volume_ul()`
#' `r roxy_meta_q_pcr_actb_ct()`
#' `r roxy_meta_q_pcr_ercc_ct()`
#' `r roxy_meta_lab_qc_passed()`
#' `r roxy_meta_pca_outlier()`
#'
#' `r roxy_cohort_data_details()`
#'
#' @inheritParams get_ga_data
#'
#' @family cohort data
#'
#' @export
get_ms_data <- function(cpm = FALSE, log2 = FALSE, tot_counts = FALSE,
                        remove_bads = TRUE,
                        remove_noncoding = TRUE, remove_pseudo = TRUE,
                        gene_predicate = NULL,
                        feather_dir = NULL) {
  checkmate::assert_flag(remove_bads)
  out <- get_cohort_data("ms",
                         cpm = cpm, log2 = log2, tot_counts = tot_counts,
                         remove_bads = remove_bads, 
                         remove_noncoding = remove_noncoding, 
                         remove_pseudo = remove_pseudo,
                         gene_predicate = gene_predicate,
                         feather_dir = feather_dir
  )
  out
}

#' `r roxy_cohort_data_title("First Trimester Gestational Age")`
#'
#' `r roxy_cohort_data_subtitle("First Trimester Gestational Age")`
#'
#' `r roxy_meta_batch_num()`
#' `r roxy_meta_mom_id()`
#' `r roxy_meta_collectionga()`
#' `r roxy_meta_sample_volume_ul()`
#' `r roxy_meta_q_pcr_actb_ct()`
#' `r roxy_meta_q_pcr_ercc_ct()`
#' `r roxy_meta_lab_qc_passed()`
#' `r roxy_meta_pca_outlier()`
#'
#' `r roxy_cohort_data_details()`
#'
#' @inheritParams get_ga_data
#'
#' @family cohort data
#'
#' @export
get_ot_data <- function(cpm = FALSE, log2 = FALSE, tot_counts = FALSE,
                        remove_bads = TRUE,
                        remove_noncoding = TRUE, remove_pseudo = TRUE,
                        gene_predicate = NULL,
                        feather_dir = NULL) {
  checkmate::assert_flag(remove_bads)
  out <- get_cohort_data("ot",
                         cpm = cpm, log2 = log2, tot_counts = tot_counts,
                         remove_bads = remove_bads, 
                         remove_noncoding = remove_noncoding, 
                         remove_pseudo = remove_pseudo,
                         gene_predicate = gene_predicate,
                         feather_dir = feather_dir
  )
  out
}


#' `r roxy_cohort_data_title("Pittsburgh Imminent Delivery")`
#'
#' `r roxy_cohort_data_subtitle("Pittsburgh Imminent Delivery")`
#'
#' `r roxy_meta_mom_id()`
#' `r roxy_meta_draw()` Most mothers have only one draw, some have two.
#' `r roxy_meta_major_race()`
#' `r roxy_meta_mom_weight_kg()`
#' `r roxy_meta_mom_height_cm()`
#' `r roxy_meta_mom_bmi()`
#' `r roxy_meta_former_smoker()`
#' `r roxy_meta_mom_age()`
#' `r roxy_meta_parity()`
#' `r roxy_meta_baby_sex()`
#' `r roxy_meta_baby_weight_g()`
#' `r roxy_meta_min_before_spin()`
#' `r roxy_meta_collectionga()`
#' `r roxy_meta_deliveryga()`
#' `r roxy_meta_weeks_to_delivery()`
#' `r roxy_meta_q_pcr_actb_ct()`
#' `r roxy_meta_q_pcr_ercc_ct()`
#' `r roxy_meta_lab_qc_passed()`
#' `r roxy_meta_pca_outlier()`
#'
#' `r roxy_cohort_data_details()`
#'
#' @inheritParams get_ga_data
#'
#' @family cohort data
#'
#' @export
get_pi_data <- function(cpm = FALSE, log2 = FALSE, tot_counts = FALSE,
                        remove_bads = TRUE,
                        remove_noncoding = TRUE, remove_pseudo = TRUE,
                        gene_predicate = NULL,
                        feather_dir = NULL) {
  checkmate::assert_flag(remove_bads)
  out <- get_cohort_data("pi",
                         cpm = cpm, log2 = log2, tot_counts = tot_counts,
                         remove_bads = remove_bads, 
                         remove_noncoding = remove_noncoding, 
                         remove_pseudo = remove_pseudo,
                         gene_predicate = gene_predicate,
                         feather_dir = feather_dir
  )
  out
}

#' `r roxy_cohort_data_title("Pemba")`
#'
#' `r roxy_cohort_data_subtitle("Pemba")`
#'
#' `r roxy_meta_collectionga()`
#' `r roxy_meta_deliveryga()`
#' `r roxy_meta_weeks_to_delivery()`
#' `r roxy_meta_sample_type()`
#' `r roxy_meta_study_purpose()` Pre-eclampsia or preterm birth.
#' `r roxy_meta_major_race()`
#' `r roxy_meta_ethnicity()`
#' `r roxy_meta_iugr()`
#' `r roxy_meta_sga()`
#' `r roxy_meta_ivf()`
#' `r roxy_meta_chronic_hypertension()`
#' `r roxy_meta_lupus()`
#' `r roxy_meta_caesarean()`
#' `r roxy_meta_stillbirth()`
#' `r roxy_meta_pre_eclampsia()`
#' `r roxy_meta_smoker()`
#' `r roxy_meta_education()`
#' `r roxy_meta_mom_bmi()`
#' `r roxy_meta_multiples()`
#' `r roxy_meta_labor_spontaneous()`
#' `r roxy_meta_labor_augmented()`
#' `r roxy_meta_mom_id()`
#' `r roxy_meta_baby_sex()`
#' `r roxy_meta_baby_weight_g()`
#' `r roxy_meta_batch_num()`
#' `r roxy_meta_sample_volume_ul()`
#' `r roxy_meta_q_pcr_actb_ct()`
#' `r roxy_meta_q_pcr_ercc_ct()`
#' `r roxy_meta_q_pcr_ver()`
#' `r roxy_meta_pca_outlier()`
#'
#' `r roxy_cohort_data_details()`
#'
#' @inheritParams get_ga_data
#'
#' @family cohort data
#'
#' @export
get_pm_data <- function(cpm = FALSE, log2 = FALSE, tot_counts = FALSE,
                        remove_bads = TRUE,
                        remove_noncoding = TRUE, remove_pseudo = TRUE,
                        gene_predicate = NULL,
                        feather_dir = NULL) {
  checkmate::assert_flag(remove_bads)
  out <- get_cohort_data("pm",
                         cpm = cpm, log2 = log2, tot_counts = tot_counts,
                         remove_bads = remove_bads, 
                         remove_noncoding = remove_noncoding, 
                         remove_pseudo = remove_pseudo,
                         gene_predicate = gene_predicate,
                         feather_dir = feather_dir
  )
  out
}

#' `r roxy_cohort_data_title("Pittsburgh")`
#'
#' `r roxy_cohort_data_subtitle("Pittsburgh")`
#'
#' `r roxy_meta_mom_id()`
#' `r roxy_meta_draw()` Most mothers have only one draw, some have two.
#' `r roxy_meta_major_race()`
#' `r roxy_meta_mom_weight_kg()`
#' `r roxy_meta_mom_height_cm()`
#' `r roxy_meta_mom_bmi()`
#' `r roxy_meta_former_smoker()`
#' `r roxy_meta_mom_age()`
#' `r roxy_meta_parity()`
#' `r roxy_meta_baby_sex()`
#' `r roxy_meta_baby_weight_g()`
#' `r roxy_meta_min_before_spin()`
#' `r roxy_meta_collectionga()`
#' `r roxy_meta_deliveryga()`
#' `r roxy_meta_weeks_to_delivery()`
#' `r roxy_meta_q_pcr_actb_ct()`
#' `r roxy_meta_q_pcr_ercc_ct()`
#' `r roxy_meta_q_pcr_ver()`
#' `r roxy_meta_lab_qc_passed()`
#' `r roxy_meta_pca_outlier()`
#'
#' `r roxy_cohort_data_details()`
#'
#' @inheritParams get_ga_data
#'
#' @family cohort data
#'
#' @export
get_pt_data <- function(cpm = FALSE, log2 = FALSE, tot_counts = FALSE,
                        remove_bads = TRUE,
                        remove_noncoding = TRUE, remove_pseudo = TRUE,
                        gene_predicate = NULL,
                        feather_dir = NULL) {
  checkmate::assert_flag(remove_bads)
  out <- get_cohort_data("pt",
                         cpm = cpm, log2 = log2, tot_counts = tot_counts,
                         remove_bads = remove_bads, 
                         remove_noncoding = remove_noncoding, 
                         remove_pseudo = remove_pseudo,
                         gene_predicate = gene_predicate,
                         feather_dir = feather_dir
  )
  out
}

#' `r roxy_cohort_data_title("Pittsburgh Four")`
#'
#' `r roxy_cohort_data_subtitle("Pittsburgh Four")`
#'
#' `r roxy_meta_batch_num()`
#' `r roxy_meta_collectionga()`
#' `r roxy_meta_deliveryga()`
#' `r roxy_meta_weeks_to_delivery()`
#' `r roxy_meta_sample_type()`
#' `r roxy_meta_study_purpose()`
#' `r roxy_meta_mom_id()`
#' `r roxy_meta_case_control_match_id()`
#' `r roxy_meta_gravida()`
#' `r roxy_meta_parity()`
#' `r roxy_meta_mom_bmi()`
#' `r roxy_meta_mom_age()`
#' `r roxy_meta_pre_eclampsia()`
#' `r roxy_meta_mom_gdm()`
#' `r roxy_meta_sample_volume_ul()`
#' `r roxy_meta_q_pcr_actb_ct()`
#' `r roxy_meta_q_pcr_ercc_ct()`
#' `r roxy_meta_pca_outlier()`
#'
#' `r roxy_cohort_data_details()`
#'
#' @inheritParams get_ga_data
#'
#' @family cohort data
#'
#' @export
get_pf_data <- function(cpm = FALSE, log2 = FALSE, tot_counts = FALSE,
                        remove_bads = TRUE,
                        remove_noncoding = TRUE, remove_pseudo = TRUE,
                        gene_predicate = NULL,
                        feather_dir = NULL) {
  checkmate::assert_flag(remove_bads)
  out <- get_cohort_data("pf",
                         cpm = cpm, log2 = log2, tot_counts = tot_counts,
                         remove_bads = remove_bads, 
                         remove_noncoding = remove_noncoding, 
                         remove_pseudo = remove_pseudo,
                         gene_predicate = gene_predicate,
                         feather_dir = feather_dir
  )
  out
}

#' `r roxy_cohort_data_title("Roskilde")`
#'
#' `r roxy_cohort_data_subtitle("Roskilde")`
#'
#' `r roxy_meta_mom_id()`
#' `r roxy_meta_draw()` Most mothers have four draws.
#' `r roxy_meta_collectionga()`
#' `r roxy_meta_deliveryga()`
#' `r roxy_meta_weeks_to_delivery()`
#' `r roxy_meta_major_race()`
#' `r roxy_meta_smoker()`
#' `r roxy_meta_conception_spontaneous()`
#' `r roxy_meta_conception_assisted()`
#' `r roxy_meta_ivf()`
#' `r roxy_meta_mom_age()`
#' `r roxy_meta_mom_weight_kg()`
#' `r roxy_meta_mom_height_cm()`
#' `r roxy_meta_mom_bmi()`
#' `r roxy_meta_parity()`
#' `r roxy_meta_baby_sex()`
#' `r roxy_meta_baby_weight_g()`
#' `r roxy_meta_baby_head_circumference_cm()`
#' `r roxy_meta_baby_length_cm()`
#' `r roxy_meta_labor_spontaneous()`
#' `r roxy_meta_labor_augmented()`
#' `r roxy_meta_q_pcr_actb_ct()`
#' `r roxy_meta_q_pcr_ercc_ct()`
#' `r roxy_meta_q_pcr_ver()`
#' `r roxy_meta_pca_outlier()`
#'
#' `r roxy_cohort_data_details()`
#'
#' @inheritParams get_ga_data
#'
#' @family cohort data
#'
#' @export
get_rs_data <- function(cpm = FALSE, log2 = FALSE, tot_counts = FALSE,
                        remove_bads = TRUE,
                        remove_noncoding = TRUE, remove_pseudo = TRUE,
                        gene_predicate = NULL,
                        feather_dir = NULL) {
  checkmate::assert_flag(remove_bads)
  out <- get_cohort_data("rs",
                         cpm = cpm, log2 = log2, tot_counts = tot_counts,
                         remove_bads = remove_bads, 
                         remove_noncoding = remove_noncoding, 
                         remove_pseudo = remove_pseudo,
                         gene_predicate = gene_predicate,
                         feather_dir = feather_dir
  )
  out
}

#' `r roxy_cohort_data_title("Stanford")`
#'
#' `r roxy_cohort_data_subtitle("Stanford")`
#'
#' `r roxy_meta_collectionga()`
#' `r roxy_meta_deliveryga()`
#' `r roxy_meta_weeks_to_delivery()`
#' `r roxy_meta_pre_eclampsia()`
#' `r roxy_meta_pca_outlier()`
#'
#' `r roxy_cohort_data_details()`
#'
#' @inheritParams get_ga_data
#'
#' @family cohort data
#'
#' @export
get_st_data <- function(cpm = FALSE, log2 = FALSE, tot_counts = FALSE,
                        remove_bads = TRUE,
                        remove_noncoding = TRUE, remove_pseudo = TRUE,
                        gene_predicate = NULL,
                        feather_dir = NULL) {
  checkmate::assert_flag(remove_bads)
  out <- get_cohort_data("st",
                         cpm = cpm, log2 = log2, tot_counts = tot_counts,
                         remove_bads = remove_bads, 
                         remove_noncoding = remove_noncoding, 
                         remove_pseudo = remove_pseudo,
                         gene_predicate = gene_predicate,
                         feather_dir = feather_dir
  )
  out
}

#' `r roxy_cohort_data_title("UPenn")`
#'
#' `r roxy_cohort_data_subtitle("UPenn")`
#'
#' `r roxy_meta_collectionga()`
#' `r roxy_meta_deliveryga()`
#' `r roxy_meta_pca_outlier()`
#'
#' `r roxy_cohort_data_details()`
#'
#' @inheritParams get_ga_data
#'
#' @family cohort data
#'
#' @export
get_up_data <- function(cpm = FALSE, log2 = FALSE, tot_counts = FALSE,
                        remove_bads = TRUE,
                        remove_noncoding = TRUE, remove_pseudo = TRUE,
                        gene_predicate = NULL,
                        feather_dir = NULL) {
  checkmate::assert_flag(remove_bads)
  out <- get_cohort_data("up",
                         cpm = cpm, log2 = log2, tot_counts = tot_counts,
                         remove_bads = remove_bads, 
                         remove_noncoding = remove_noncoding, 
                         remove_pseudo = remove_pseudo,
                         gene_predicate = gene_predicate,
                         feather_dir = feather_dir
  )
  out
}

#' Get the data for a given cohort.
#'
#' @param cohort A two-character string. The cohort code.
#' @inheritParams get_ga_data
#'
#' @return A tibble.
#'
#' @noRd
get_cohort_data <- function(cohort, cpm, log2, tot_counts, 
                            remove_bads, remove_noncoding, remove_pseudo,
                            gene_predicate, feather_dir) {
  insist_mirmisc()
  checkmate::assert_string(cohort)
  checkmate::assert_true(nchar(cohort) == 2)
  cohort <- stringr::str_to_upper(cohort)
  checkmate::assert_flag(cpm)
  checkmate::assert_flag(log2)
  checkmate::assert_flag(tot_counts)
  checkmate::assert_flag(remove_bads)
  checkmate::assert(
    checkmate::check_function(gene_predicate, null.ok = TRUE),
    checkmate::check_formula(gene_predicate, null.ok = TRUE)
  )
  checkmate::assert_flag(remove_noncoding)
  checkmate::assert_flag(remove_pseudo)
  checkmate::assert_string(feather_dir, null.ok = TRUE)
  if (is.null(feather_dir)) {
    path <- mirmisc::get_feather_path(
      glue::glue("{cohort}_raw_counts.feather")
    )
  } else {
    path <- fs::path(feather_dir, glue::glue("{cohort}_raw_counts.feather"))
  }
  counts <- arrow::read_feather(path)
  if (cpm || log2 || tot_counts) {
    gene_counts_raw <- gene_counts <- counts %>%
      dplyr::select(-"mirvie_id") %>%
      as.matrix()
    if (cpm) gene_counts <- gene_counts / rowSums(gene_counts) * 1e6
    if (log2) gene_counts <- log2(gene_counts + 1)
    counts <- dplyr::bind_cols(
      counts["mirvie_id"],
      dplyr::as_tibble(gene_counts)
    )
    if (tot_counts) {
      counts$tot_counts <- rowSums(gene_counts_raw, na.rm = TRUE)
      if (log2) counts$log2_tot_counts <- log2(counts$tot_counts + 1)
    }
  }
  counts <- remove_strange_genes(counts,
                                 remove_noncoding = remove_noncoding,
                                 remove_pseudo = remove_pseudo)
  counts <- stats::na.omit(counts)
  if (!is.null(gene_predicate)) {
    counts <- dplyr::bind_cols(
      counts["mirvie_id"],
      purrr::keep(
        dplyr::select(counts, -"mirvie_id"),
        rlang::as_function(gene_predicate)
      )
    )
  }
  if (is.null(feather_dir)) {
    path_meta <- mirmisc::get_feather_path(
      glue::glue("{cohort}_meta.feather")
    )
  } else {
    path_meta <- fs::path(feather_dir, glue::glue("{cohort}_meta.feather"))
  }
  meta <- arrow::read_feather(path_meta)
  checkmate::assert_character(counts$mirvie_id, unique = TRUE)
  checkmate::assert_character(meta$mirvie_id, unique = TRUE)
  counts <- dplyr::filter(counts, .data[["mirvie_id"]] %in% meta$mirvie_id) 
  out <- dplyr::bind_cols(
    counts,
    meta[match(counts$mirvie_id, meta$mirvie_id), ] %>%
      dplyr::select(-"mirvie_id")
  )
  if (remove_bads) {
    out <- remove_bad_samples(out)
  }
  out %>%
    dplyr::mutate(
      cohort = factor(stringr::str_sub(.data[["mirvie_id"]], 1, 2))
    ) %>%
    dplyr::select("mirvie_id", "cohort", dplyr::everything())
}

#' Retrieve the data from many cohorts combined.
#'
#' Only columns present in all of the cohorts will be kept.
#'
#' @param cohorts A character vector. A subset of `c("bw", "ga", "io", "kl",
#'   "ms", "ot", "pf", "pg", "pi", "pm", "pt", "rs", "st", "up", "vg")`.
#' @inheritParams get_ga_data
#' @param col_combine A string. Either `"intersect"` (the default) or `"union"`.
#'   Different cohorts have different metadata columns. This parameter specifies
#'   how to deal with this. With `"intersect"`, only columns present in all
#'   cohorts are kept, whereas with `"union"`, all columns are kept, using `NA`s
#'   to fill.
#' @param n_cores A positive integer. Number of cores to read each of the
#'   cohorts in parallel.
#'
#' @return A data frame.
#'
#' @export
get_combined_cohort_data <- function(cohorts = c(
                                       "bw", "ga", "io", "kl", "ms", "ot", "pf",
                                       "pg", "pi", "pm", "pt", "rs", "st", "up",
                                       "vg"
                                     ),
                                     cpm = FALSE, log2 = FALSE,
                                     tot_counts = FALSE, remove_bads = TRUE,
                                     col_combine = c("intersect", "union"),
                                     remove_noncoding = TRUE,
                                     remove_pseudo = TRUE,
                                     gene_predicate = NULL,
                                     feather_dir = NULL,
                                     n_cores = 1) {

  # Argument checking ----------------------------------------------------------
  checkmate::assert_flag(cpm)
  checkmate::assert_flag(log2)
  checkmate::assert_flag(tot_counts)
  checkmate::assert_flag(remove_bads)
  checkmate::assert_character(cohorts,
    min.len = 1, min.chars = 2,
    unique = TRUE
  )
  cohorts <- tolower(cohorts)
  checkmate::assert_names(
    cohorts,
    subset.of = c(
      "bw", "dp", "ga", "io", "kl", "ms", "ot", "pf", "pg", "pi", "pm", "pt",
      "rs", "st", "up", "vg"
    )
  )
  n_cores <- checkmate::assert_int(n_cores, lower = 1, coerce = TRUE)
  if (isTRUE(all.equal(col_combine, c("intersect", "union")))) {
    col_combine <- col_combine[1]
  }
  checkmate::assert_string(col_combine)
  checkmate::assert(
    checkmate::check_function(gene_predicate, null.ok = TRUE),
    checkmate::check_formula(gene_predicate, null.ok = TRUE)
  )
  checkmate::assert_flag(remove_noncoding)
  checkmate::assert_flag(remove_pseudo)

  # Parallel setup -------------------------------------------------------------
  old_plan <- future::plan(future::multisession, workers = n_cores)
  on.exit(future::plan(old_plan), add = TRUE)

  # Main body ------------------------------------------------------------------
  col_combine <- strex::match_arg(col_combine, ignore_case = TRUE)
  calls <- stringr::str_glue(
    "get_{cohorts}_data(",
    "cpm = {cpm}, log2 = {log2}, ",
    "tot_counts = {tot_counts}, ",
    "feather_dir = {feather_dir}, ",
    "remove_noncoding = FALSE, ",
    "remove_pseudo = FALSE, ",
    "remove_bads = {remove_bads})",
    .envir = list(
      cohorts = cohorts, cpm = cpm, log2 = log2, tot_counts = tot_counts,
      feather_dir = dplyr::if_else(
        is.null(feather_dir), "NULL",
        stringr::str_c("\"", feather_dir, "\"")
      ),
      remove_bads = remove_bads
    )
  )
  cohort_data <- furrr::future_map(
    calls, ~ eval(parse(text = .)),
    .options = furrr::furrr_options(seed = get_seed())
  )
  if (col_combine == "intersect") {
    common_colnames <- cohort_data %>%
      purrr::map(names) %>%
      purrr::reduce(intersect)
    cohort_data <- cohort_data %>%
      purrr::map(~ dplyr::select(., dplyr::all_of(common_colnames)))
  }
  out <- dplyr::bind_rows(cohort_data) %>% 
    remove_strange_genes(remove_noncoding = remove_noncoding,
                         remove_pseudo = remove_pseudo)
  if (!is.null(gene_predicate)) {
    insist_mirmisc()
    gene_names <- mirmisc::get_df_gene_names(out)
    get_rid_genes <- out[gene_names] %>%
      purrr::map_lgl(rlang::as_function(gene_predicate)) %>%
      .[!.] %>%
      names()
    out <- dplyr::select(out, -dplyr::all_of(get_rid_genes))
  }
  out
}

#' Remove suspect samples.
#'
#' These are samples that have no `mirvie_id`, have no ACTB counts, have
#' failed some lab metrics or are not from during a pregnancy.
#'
#' @param df A data frame.
#'
#' @return A data frame.
#'
#' @noRd
remove_bad_samples <- function(df) {
  out <- dplyr::filter(df, !is.na(.data[["mirvie_id"]]))
  if ("ACTB" %in% names(out)) {
    out <- dplyr::filter(out, .data[["ACTB"]] > 0)
  }
  if ("meta_lab_qc_passed" %in% names(out)) {
    out <- dplyr::filter(
      out, 
      purrr::map_lgl(.data[["meta_lab_qc_passed"]], ~!isFALSE(.))
    )
  }
  if (all(c("meta_collectionga", "meta_deliveryga") %in% names(out))) {
    out <- dplyr::filter( # only keep samples of currently pregnant women
      out,
      (.data[["meta_collectionga"]] > 0) & 
        (.data[["meta_deliveryga"]] > .data[["meta_collectionga"]])
    )
  }
  out
}

#' Optionally remove non-coding and/or pseudo genes.
#' 
#' @param df A data frame with column names that are gene names.
#' @param remove_pseudo,remove_noncoding Flags.
#' 
#' @return A data frame.
#' 
#' @noRd
remove_strange_genes <- function(df, remove_noncoding, remove_pseudo) {
  insist_mirmisc()
  checkmate::assert_data_frame(df)
  checkmate::assert_flag(remove_noncoding)
  checkmate::assert_flag(remove_pseudo)
  if (remove_noncoding || remove_pseudo) {
    gene_types <- arrow::read_feather(
      system.file("extdata", "ensembl-gene-types.feather",
                  package = "mirmodels")
    ) %>% 
      stats::na.omit()
    gene_types <- dplyr::bind_rows(
      gene_types,
      dplyr::mutate(
        gene_types, 
        gene_id = mirmisc::convert_gene_names(.data[["gene_id"]], "from")
      ) 
    )
    bad_genes <- character()
    if (remove_pseudo) {
      bad_genes <- c(
        bad_genes,
        dplyr::filter(
          gene_types, 
          stringr::str_detect(.data[["transcript_biotype"]], "pseudo")
        )[["gene_id"]]
      )
    }
    if (remove_noncoding) {
      bad_genes <- c(
        bad_genes,
        dplyr::filter(
          gene_types, 
          stringr::str_detect(.data[["transcript_biotype"]], "nc|antisense")
        )[["gene_id"]]
      )
      processed_transcript_onlys <- gene_types %>% 
        dplyr::group_by(.data[["gene_id"]]) %>% 
        dplyr::filter(dplyr::n() == 1) %>% 
        dplyr::ungroup() %>% 
        dplyr::filter(
          .data[["transcript_biotype"]] == "processed_transcript"
        ) %>% 
        dplyr::pull("gene_id")
      bad_genes <- c(bad_genes, processed_transcript_onlys)
    }
    before_dots_in_bad_genes <- names(df)[
      strex::str_before_last_dot(names(df)) %in% bad_genes
    ]
    bad_genes <- c(bad_genes, before_dots_in_bad_genes)
    df <- dplyr::select(df, -dplyr::any_of(bad_genes))
  }
  df
}
