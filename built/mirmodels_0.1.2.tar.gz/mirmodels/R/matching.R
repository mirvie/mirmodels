#' Match cases with controls based on some auxiliary variable(s).
#'
#' @param df A data frame with a column called `mirvie_id`.
#' @param outcome A string. The name of the outcome variable. Must be a name of
#'   a column of `df`. That column must be a logical
#' @param match_on A character vector. Variable(s) to match the cases and
#'   controls by.
#' @param ratio A number. The case-control ratio. `ratio = 2` will give 2
#'   controls per case. `ratio = 1/3` will give 3 cases per control.
#'
#' @return A data frame which is a subset of the rows of `df`. All cases are
#'   returned along with the matched controls.
#'
#' @export
subset_to_matched <- function(df, outcome, match_on, ratio = 1) {
  checkmate::assert_data_frame(df, min.rows = 2, min.cols = 2)
  checkmate::assert_string(outcome, min.chars = 1)
  checkmate::assert_character(match_on, min.chars = 1, min.len = 1)
  checkmate::assert_number(ratio, lower = 0)
  checkmate::assert_names(c(outcome, match_on, "mirvie_id"),
                          subset.of = names(df))
  checkmate::assert_disjunct(outcome, match_on)
  checkmate::assert_false(anyNA(df[c(outcome, match_on)]))
  if (is.logical(df[[outcome]])) df[[outcome]] <- factor(df[[outcome]])
  df_rownamed <- data.frame(df, row.names = "mirvie_id")
  formula <- as.formula(paste(outcome, "~", paste(match_on, collapse = " + ")))
  mirvie_ids <- MatchIt::matchit(
    formula = formula,
    data = df_rownamed,
    method = "optimal",
    ratio = ratio
  ) %>%
    purrr::pluck("match.matrix") %>%
    dplyr::as_tibble(rownames = "mirvie_id", .name_repair = "minimal") %>%
    unname() %>%
    unlist()
  dplyr::filter(df, .data[["mirvie_id"]] %in% mirvie_ids)
}
