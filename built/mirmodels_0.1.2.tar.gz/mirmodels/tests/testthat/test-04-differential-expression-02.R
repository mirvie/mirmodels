test_that("`cor_de()` finds CAPN6 for collectionga in GAPPS", {
  ga_data <- get_ga_data(gene_predicate = ~ median(.) > 0)
  de <- cor_de(ga_data, "meta_collectionga")
  expect_lt(dplyr::filter(de, gene == "CAPN6")$padj, 0.01)
})

test_that("DE argument checking works", {
  skip_if_not_installed("mirmisc")
  bw_data <- get_bw_data()
  bw_data$meta_pre_eclampsia <- factor("TRUE")
  expect_error(
    edger(bw_data, "meta_pre_eclampsia"),
    "data.+condition.+should be a factor with 2 levels.+has 1 level"
  )
  bw_data$meta_pre_eclampsia <- factor("TRUE", levels = c("TRUE", "xyz"))
  expect_error(
    edger(bw_data, "meta_pre_eclampsia"),
    "All levels.+data.+condition.+should be present.+xyz.+absent"
  )
  bw_data <- dplyr::select(
    bw_data,
    -dplyr::any_of(mirmisc::get_gene_names())
  )
  expect_error(
    edger(bw_data, "meta_pre_eclampsia"),
    "No gene names found"
  )
})

test_that("edgeR works with batch specified as integer or character", {
  bw_data <- dplyr::filter(get_bw_data(), !is.na(meta_pre_eclampsia))
  de <- edger(dplyr::mutate(bw_data, meta_batch_num = factor(meta_batch_num)),
    "meta_pre_eclampsia",
    batch = "meta_batch_num"
  )
  expect_equal(
    de %>%
      dplyr::arrange(gene),
    edger(dplyr::mutate(bw_data, meta_batch_num = as.integer(meta_batch_num)),
      "meta_pre_eclampsia",
      batch = "meta_batch_num"
    ) %>%
      dplyr::arrange(gene),
    tolerance = 1e-5
  )
  expect_equal(
    de %>%
      dplyr::arrange(gene),
    edger(dplyr::mutate(bw_data, meta_batch_num = as.character(meta_batch_num)),
      "meta_pre_eclampsia",
      batch = "meta_batch_num"
    ) %>%
      dplyr::arrange(gene),
    tolerance = 1e-5
  )
})
