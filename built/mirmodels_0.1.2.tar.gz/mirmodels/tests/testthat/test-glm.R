test_that(paste(
  "`train_glm()` has near-perfect prediction on a binarized",
  "(greater or less than the mean) numeric outcome when given",
  "the squared numeric outcome as a predictor"
), {
  rs_nearperfect_data <- get_rs_data(gene_predicate = ~ median(.) > 0) %>%
    dplyr::filter(!is.na(meta_deliveryga)) %>%
    dplyr::mutate(
      out_sq = meta_deliveryga^2,
      less_greater = factor(dplyr::if_else(
        meta_deliveryga <= mean(meta_deliveryga),
        "less", "greater"
      ))
    ) %>%
    dplyr::select(-dplyr::starts_with("meta_", ignore.case = FALSE), -cohort)
  set.seed(1)
  rs_nearperfect_data_split <- rsample::initial_split(rs_nearperfect_data,
    strata = less_greater
  )
  rs_nearperfect_training_data <- rsample::training(rs_nearperfect_data_split)
  rs_nearperfect_testing_data <- rsample::testing(rs_nearperfect_data_split)
  mod <- train_glm(rs_nearperfect_training_data, "less_greater",
    id_col = "mirvie_id", strata = "less_greater",
    metric = "mn_log_loss"
  )
  preds <- stats::predict(mod, new_data = rs_nearperfect_testing_data)
  expect_lte(mean(preds[[1]] != rs_nearperfect_testing_data$less_greater), 0.1)
})

test_that(paste(
  "`train_glm()` has perfect categorical predictions with",
  "a perfect predictor"
), {
  skip_if_not_installed("mirmisc")
  ga_perfect_data <- get_ga_data(
    cpm = TRUE,
    gene_predicate = ~ median(.) > 0
  ) %>%
    dplyr::mutate(
      race_otherized_pred = forcats::fct_lump_prop(meta_major_race, 0.1),
      race_otherized_out = race_otherized_pred
    ) %>%
    dplyr::select(
      dplyr::starts_with("race"), mirvie_id,
      dplyr::starts_with("meta")
    ) %>%
    .[seq_len(10)] %>%
    dplyr::select(
      mirvie_id, dplyr::any_of(mirmisc::get_gene_names()),
      race_otherized_out, race_otherized_pred
    ) %>%
    stats::na.omit() %>%
    dplyr::mutate(race_otherized_out = forcats::fct_drop(race_otherized_out))
  set.seed(1)
  ga_perfect_data_split <- rsample::initial_split(ga_perfect_data,
    strata = race_otherized_out
  )
  ga_perfect_training_data <- rsample::training(ga_perfect_data_split)
  ga_perfect_testing_data <- rsample::testing(ga_perfect_data_split)
  mod_medianimpute <- train_glm(
    ga_perfect_training_data, "race_otherized_out",
    lambda = 0, strata = "race_otherized_out",
    na_action = "medianimpute",
    id_col = "mirvie_id", cv_nfolds = 7,
    metric = "accuracy"
  )
  preds <- stats::predict(mod_medianimpute, new_data = ga_perfect_testing_data)
  expect_equal(preds[[1]], ga_perfect_testing_data$race_otherized_out)
  mod_knnimpute <- train_glm(ga_perfect_training_data, "race_otherized_out",
    lambda = 0,
    na_action = "knnimpute", strata = "race_otherized_out",
    id_col = "mirvie_id", cv_nfolds = 8,
    metric = "accuracy"
  )
  preds <- stats::predict(mod_knnimpute, new_data = ga_perfect_testing_data)
  expect_equal(preds[[1]], ga_perfect_testing_data$race_otherized_out)
})

test_that("Repeated runs produce the same output", {
  pt_data <- get_pt_data(log2 = TRUE, gene_predicate = ~ median(.) > 0) %>%
    dplyr::select(
      -dplyr::starts_with("meta_", ignore.case = FALSE),
      meta_major_race
    ) %>%
    dplyr::filter(meta_major_race %in% c("afro_american", "white")) %>%
    dplyr::mutate(meta_major_race = forcats::fct_drop(meta_major_race))
  pt_data_split <- rsample::initial_split(pt_data)
  pt_training_data <- rsample::training(pt_data_split)
  pt_testing_data <- rsample::testing(pt_data_split)
  models <- as.list(1:2)
  for (i in seq_along(models)) {
    set.seed(1)
    models[[i]] <- train_glm(pt_training_data, "meta_major_race",
      id_col = "mirvie_id", cv_nfolds = 4,
      metric = "accuracy",
      include_nullmod = FALSE
    )
  }
  expect_equal(
    stats::predict(models[[1]], new_data = pt_testing_data),
    stats::predict(models[[2]], new_data = pt_testing_data)
  )
})

test_that("With random predictors and enough data, null model is returned", {
  set.seed(1)
  x <- replicate(99, runif(9999)) %>%
    magrittr::set_names(stringr::str_c("x", seq_along(.))) %>%
    as.data.frame()
  data <- x %>%
    dplyr::mutate(y = dplyr::if_else(runif(nrow(x)) > 0.5, "a", "b"))
  data_split <- rsample::initial_split(data)
  training_data <- rsample::training(data_split)
  expect_error(
    train_glm(training_data, "y",
      selection_method = "abs",
      metric = "mn_log_loss",
      cv_nfolds = 4,
      include_nullmod = TRUE, err_if_nullmod = TRUE
    ),
    "null model performed better"
  )
  expect_warning(
    mod <- train_glm(
      training_data, "y",
      selection_method = "abs",
      metric = "accuracy",
      include_nullmod = TRUE, err_if_nullmod = FALSE
    ),
    "Returning the null model"
  )
  expect_equal(
    workflows::pull_workflow_fit(mod)$spec$method$fit$func,
    c(fun = "nullmodel")
  )
})

test_that("Model can overfit to near-perfect prediction on the training data", {
  skip_if_not_installed("datasets")
  iris_data <- janitor::clean_names(datasets::iris)
  mod <- train_glm(
    iris_data, "species",
    lambda = 0,
    selection_method = "abs",
    metric = "accuracy",
    include_nullmod = FALSE
  )
  truth <- iris_data$species
  preds <- predict(mod, new_data = iris_data)[[1]]
  expect_lt(mean(truth != preds), 0.05)
})

test_that("train_glm() errors as expected", {
  training_data <- dplyr::tibble(x = list(1:2), y = 1:2)
  expect_error(
    train_glm(
      training_data = training_data,
      outcome = "y"
    ),
    paste0(
      "All elements of.+training_data.+must.+numeric.+factor.+character",
      ".+column.+x.+is not"
    )
  )
  training_data <- dplyr::tibble(x = 1:2, y = 1)
  expect_error(
    train_glm(
      training_data = training_data,
      outcome = "y"
    ),
    "Your outcome must have at least two distinct values"
  )
  training_data$y <- as.logical(round(runif(nrow(training_data))))
  expect_error(
    train_glm(
      training_data = training_data,
      outcome = "y"
    ),
    "Your outcome should not be of logical.+type."
  )
  training_data$y <- as.character(3:4)
  expect_error(
    train_glm(
      training_data = training_data,
      outcome = "y", selection_method = "Breiman",
    ),
    "Each multinomial class must have at least 5 instances."
  )
  expect_error(
    train_glm(
      training_data = training_data,
      outcome = "y", selection_method = "Breiman",
    ),
    "Each multinomial class must have at least 5 instances."
  )
  iris_data <- janitor::clean_names(datasets::iris)
  expect_error(
    train_glm(
      iris_data, "species",
      lambda = 0,
      selection_method = "abs",
      metric = "mae",
      include_nullmod = FALSE
    ),
    "select a probability metric"
  )
})
