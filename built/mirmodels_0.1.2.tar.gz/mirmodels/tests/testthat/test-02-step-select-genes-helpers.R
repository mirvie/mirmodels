test_that("`prep_step_select_genes()` basics work", {
  skip_if_not_installed("mirmisc")
  set.seed(1)
  ms_data <- get_ms_data() %>%
    dplyr::select(
      mirvie_id, meta_pre_eclampsia,
      dplyr::any_of(mirmisc::get_gene_names())
    ) %>%
    dplyr::mutate(meta_pre_eclampsia = factor(meta_pre_eclampsia)) %>%
    dplyr::filter(!is.na(meta_pre_eclampsia))
  rec <- recipes::recipe(ms_data) %>%
    recipes::update_role(dplyr::everything(), new_role = "predictor") %>%
    recipes::update_role(meta_pre_eclampsia, new_role = "outcome") %>%
    recipes::update_role(mirvie_id, new_role = "ID") %>%
    step_select_genes(recipes::all_predictors(),
      condition = "meta_pre_eclampsia",
      padj_cutoff = 1e-99, min_n_genes = 1,
      id = "select_genes_Qnr6Y"
    )
  expect_equal(
    prep_step_select_genes(rec$steps[[1]], ms_data, summary(rec)),
    prep(rec, strings_as_factors = FALSE)$steps[[1]]
  )
  rec <- recipes::recipe(ms_data) %>%
    recipes::update_role(dplyr::everything(), new_role = "predictor") %>%
    recipes::update_role(meta_pre_eclampsia, new_role = "outcome") %>%
    recipes::update_role(mirvie_id, new_role = "ID") %>%
    step_select_genes(recipes::all_predictors(),
      condition = "meta_pre_eclampsia",
      padj_cutoff = 0.1, max_n_genes = 9,
      id = "select_genes_Qnr6Y",
      options = list(method = "spearman", padj_method = "none")
    )
  expect_equal(
    prep_step_select_genes(rec$steps[[1]], ms_data, summary(rec)),
    prep(rec, strings_as_factors = FALSE)$steps[[1]]
  )
})

test_that("`tidy_step_select_genes()` basics work", {
  skip_if_not_installed("mirmisc")
  x <- list(
    trained = TRUE,
    genes_pass = list(good = "g", bad = "b")
  )
  expect_equal(
    tidy_step_select_genes(x),
    dplyr::tibble(gene = c("g", "b"), pass = c(TRUE, FALSE))
  )
  x$trained <- FALSE
  x$terms <- "recipes::all_predictors()"
  expect_equal(
    tidy_step_select_genes(x),
    dplyr::tibble(
      gene = "recipes::all_predictors()",
      pass = rlang::na_lgl
    )
  )
})

test_that("`print_step_select_genes()` basics work", {
  skip_if_not_installed("mirmisc")
  x <- list(trained = TRUE, genes_pass = list(good = "XYZ"))
  expect_match(
    capture.output(print_step_select_genes(x)),
    paste("Differential expression based gene selection selecting 1 gene: XYZ")
  )
  x$genes_pass$good <- c("ABC", "XYZ")
  expect_match(
    capture.output(print_step_select_genes(x)),
    paste(
      "Differential expression based gene selection selecting 2 genes",
      "including ABC"
    )
  )
  x$trained <- FALSE
  x$terms <- rlang::quos(recipes::all_predictors())
  expect_match(
    capture.output(print_step_select_genes(x)),
    paste(
      "Differential expression based gene selection on",
      "recipes::all_predictors"
    )
  )
})

test_that("`tunable_step_select_genes()` basics work", {
  skip_if_not_installed("mirmisc")
  expect_equal(
    tunable_step_select_genes(list(id = "abc")),
    dplyr::tibble(
      name = c("padj_cutoff"),
      call_info = list(list(pkg = "mirmodels", fun = "padj_cutoff")),
      source = "recipe",
      component = "step_select_genes",
      component_id = "abc"
    )
  )
})
