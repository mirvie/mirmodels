test_that("subset_to_match() works", {
  kl_data <- get_kl_data() %>% 
    dplyr::filter(!is.na(meta_mom_gdm))
  kl_matched_gdm_bmi <- subset_to_matched(
    kl_data,
    outcome = "meta_mom_gdm",
    match_on = "meta_mom_bmi",
    ratio = 5
  )
  expect_lt(nrow(kl_matched_gdm_bmi), nrow(kl_data))
  kl_gdm_bmi_summaries <- kl_matched_gdm_bmi %>% 
    dplyr::group_by(meta_mom_gdm) %>% 
    dplyr::group_split() %>% 
    purrr::map(~summary(.$meta_mom_bmi)[2:5])
  expect_equal(kl_gdm_bmi_summaries[[1]], kl_gdm_bmi_summaries[[2]],
               tolerance = 1)
})
