test_that("`linear_correct()` works", {
  skip_if_not_installed("mirmisc")
  data <- get_combined_cohort_data(
    c("bw", "ga", "kl", "rs"),
    log2 = TRUE, tot_counts = TRUE,
    gene_predicate = ~ median(.) > 8
  ) %>%
    dplyr::mutate(tot_counts = log2(tot_counts))
  res <- linear_correct(data,
    correct_cols = intersect(mirmisc::get_gene_names(), names(data)),
    correct_for_cols = c("meta_q_pcr_actb_ct", "tot_counts", "cohort"),
    robust = FALSE
  )[[1]]
  expect_gt(
    abs(cor(data$ACTB, data$tot_counts)),
    abs(cor(res$ACTB, res$tot_counts))
  )
  expect_gt(
    abs(cor(data$ACTB, as.integer(data$cohort == "KL"))),
    abs(cor(res$ACTB, as.integer(res$cohort == "KL")))
  )
  ptb_genes <- c(
    "HRG", "APOB", "FGA", "ALB", "FGB", "RORA", "HPD", "PAPPA2",
    "APOH"
  )
  data <- get_combined_cohort_data(
    c("io", "kl", "pi", "pm", "rs", "st", "up"),
    log2 = TRUE, tot_counts = TRUE,
    col_combine = "union",
    gene_predicate = ~ median(.) > 0
  ) %>%
    dplyr::mutate(tot_counts = log2(tot_counts))
  ptb_data <- data %>%
    dplyr::select(
      -dplyr::any_of(setdiff(mirmisc::get_gene_names(), ptb_genes))
    ) %>%
    dplyr::filter(!is.na(meta_q_pcr_actb_ct))
  ptb_data_split <- rsample::initial_split(ptb_data, strata = meta_collectionga)
  res <- linear_correct(
    ptb_data_split,
    correct_cols = ptb_genes,
    correct_for_cols = c("meta_q_pcr_actb_ct", "tot_counts", "cohort"),
    keep_effect_cols = "meta_collectionga",
    robust = FALSE
  ) %>%
    conv_traintest_lst_to_rsplit()
  expect_gt(
    abs(
      cor(
        rsample::training(ptb_data_split)$APOB,
        as.integer(rsample::training(ptb_data_split)$cohort == "KL")
      )
    ),
    abs(
      cor(
        rsample::training(res)$APOB,
        as.integer(rsample::training(res)$cohort == "KL")
      )
    )
  )
  expect_gt(
    abs(
      cor(
        rsample::testing(ptb_data_split)$APOB,
        as.integer(rsample::testing(ptb_data_split)$cohort == "KL")
      )
    ),
    abs(
      cor(
        rsample::testing(res)$APOB,
        as.integer(rsample::testing(res)$cohort == "KL")
      )
    )
  )
})

test_that("`linear_correct()` errors correctly", {
  df <- dplyr::tibble(
    x1 = 1:100, x2 = x1 + 1, x3 = x2 + 1, x4 = "a", x5 = 5,
    y1 = 1, y2 = 2
  )
  expect_error(
    linear_correct(df,
      correct_for_cols = paste0("x", 1:4),
      correct_cols = c("y1", "y2")
    ),
    "Assertion.+failed.+element 4 has type.+character"
  )
  expect_error(
    linear_correct(df,
      correct_for_cols = paste0("x", 1:3),
      correct_cols = c("y1", "y2"),
      keep_effect_cols = "x4"
    ),
    "May only contain.+numeric.+factor.+logical.+element 1.+type.+character"
  )
  df$x4 <- 4
  df$y1 <- "a"
  expect_error(
    linear_correct(df,
      correct_for_cols = paste0("x", 1:3),
      correct_cols = c("y1", "y2"),
      keep_effect_cols = "x4"
    ),
    "May only contain.+numeric.+element 1.+type.+character"
  )
})
