test_that("`step_select_genes()` works", {
  skip_if_not_installed("mirmisc")
  set.seed(1)
  ms_data <- get_ms_data(gene_predicate = ~ median(.) > 0) %>%
    dplyr::select(
      mirvie_id, meta_pre_eclampsia,
      dplyr::any_of(mirmisc::get_gene_names())
    ) %>%
    dplyr::mutate(meta_pre_eclampsia = factor(meta_pre_eclampsia)) %>%
    dplyr::filter(!is.na(meta_pre_eclampsia))
  genes <- dplyr::intersect(mirmisc::get_gene_names(), names(ms_data))
  genes_exclude <- dplyr::setdiff(
    sample(genes, length(genes) * 0.99),
    c("PAPPA2", "AOX1")
  )
  ms_data <- dplyr::select(ms_data, -dplyr::all_of(genes_exclude)) # for speed
  rec <- recipes::recipe(ms_data) %>%
    recipes::update_role(dplyr::everything(), new_role = "predictor") %>%
    recipes::update_role(meta_pre_eclampsia, new_role = "outcome") %>%
    recipes::update_role(mirvie_id, new_role = "ID") %>%
    step_select_genes(recipes::all_predictors(),
      condition = "meta_pre_eclampsia",
      padj_cutoff = 0.9,
      id = "select_genes_Qnr6Y"
    )
  expect_snapshot(print(rec$steps[[1]]))
  expect_equal(print(rec$steps[[1]]), print_step_select_genes(rec$steps[[1]]))
  expect_equal(tidy(rec, 1), tidy(rec$steps[[1]]))
  expect_equal(tidy(rec, 1), tidy_step_select_genes(rec$steps[[1]]))
  expect_snapshot_value(tidy(rec, 1), style = "serialize")
  expect_snapshot_value(tunable(rec), style = "serialize")
  expect_true(
    "PAPPA2" %in%
      prep(rec$steps[[1]],
        training = ms_data, info = rec$term_info
      )$genes_pass$good
  )
  prepped_rec <- prep(rec, strings_as_factors = FALSE)
  expect_snapshot(print(prepped_rec$steps[[1]]))
  expect_equal(
    print(prepped_rec$steps[[1]]),
    print_step_select_genes(prepped_rec$steps[[1]])
  )
  expect_snapshot_value(tunable(prepped_rec), style = "serialize")
  expect_equal(tunable(prepped_rec), tunable(prepped_rec$steps[[1]]))
  expect_equal(
    tunable(prepped_rec),
    tunable_step_select_genes(prepped_rec$steps[[1]])
  )
  tidy_prepped <- tidy(prepped_rec, 1)
  expect_equal(tidy_prepped, tidy(prepped_rec$steps[[1]]))
  expect_equal(tidy_prepped, tidy_step_select_genes(prepped_rec$steps[[1]]))
  expect_true("PAPPA2" %in% dplyr::filter(tidy_prepped, pass)$gene)
  expect_equal(
    bake(prepped_rec, new_data = NULL),
    bake_step_select_genes(prepped_rec$steps[[1]], new_data = ms_data)
  )
  rec <- recipes::recipe(ms_data) %>%
    recipes::update_role(dplyr::everything(), new_role = "predictor") %>%
    recipes::update_role(meta_pre_eclampsia, new_role = "outcome") %>%
    recipes::update_role(mirvie_id, new_role = "ID") %>%
    step_select_genes(recipes::all_predictors(),
      condition = "meta_pre_eclampsia",
      padj_cutoff = 1e-99, min_n_genes = 1,
      id = "select_genes_Qnr6Y"
    )
  prepped_rec <- prep(rec, strings_as_factors = FALSE)
  expect_equal(length(prepped_rec$steps[[1]]$genes_pass$good), 1)
  rec <- recipes::recipe(ms_data) %>%
    recipes::update_role(dplyr::everything(), new_role = "predictor") %>%
    recipes::update_role(meta_pre_eclampsia, new_role = "outcome") %>%
    recipes::update_role(mirvie_id, new_role = "ID") %>%
    step_select_genes(recipes::all_predictors(),
      condition = "meta_pre_eclampsia",
      padj_cutoff = 0.9, max_n_genes = 9,
      id = "select_genes_Qnr6Y",
      options = list(method = "spearman", padj_method = "none")
    )
  prepped_rec <- prep(rec, strings_as_factors = FALSE)
  expect_equal(length(prepped_rec$steps[[1]]$genes_pass$good), 9)
  rec <- recipes::recipe(ms_data) %>%
    recipes::update_role(dplyr::everything(), new_role = "predictor") %>%
    recipes::update_role(meta_pre_eclampsia, new_role = "outcome") %>%
    recipes::update_role(mirvie_id, new_role = "ID") %>%
    step_select_genes(recipes::all_predictors(),
      condition = "meta_pre_eclampsia",
      padj_cutoff = tune::tune()
    )
  mod <- parsnip::logistic_reg(penalty = 0, mixture = 0) %>%
    parsnip::set_engine("glm")
  wf <- workflows::workflow() %>%
    workflows::add_recipe(rec) %>%
    workflows::add_model(mod)
  rs <- rsample::vfold_cv(ms_data, v = 3, strata = meta_pre_eclampsia)
  tb <- suppressWarnings(
    tune::tune_bayes(
      wf, rs,
      param_info = dials::parameters(wf) %>%
        stats::update(padj_cutoff = padj_cutoff(range = c(0, 0.2))),
      initial = 9, iter = 2
    )
  )
  expect_true(
    dplyr::between(
      tune::select_best(tb, metric = "accuracy")$padj_cutoff,
      0, 0.2
    )
  )
})

test_that("`step_select_genes()` can be used on iris", {
  set.seed(1)
  iris_data <- janitor::clean_names(dplyr::as_tibble(datasets::iris))
  rec <- recipes::recipe(iris_data) %>%
    recipes::update_role(dplyr::everything(), new_role = "predictor") %>%
    recipes::update_role(species, new_role = "outcome") %>%
    step_select_genes(recipes::all_predictors(),
      condition = "meta_pre_eclampsia",
      padj_cutoff = 0.05,
      id = "select_genes_4dMaH"
    )
  mod <- parsnip::multinom_reg(penalty = 0, mixture = 0) %>%
    parsnip::set_engine("glmnet")
  expect_snapshot_value(tidy_step_select_genes(rec$steps[[1]]),
    style = "serialize"
  )
  expect_equal(tidy(rec, 1), tidy_step_select_genes(rec$steps[[1]]))
})

test_that("`step_select_genes()` errors and edge cases work", {
  skip_if_not_installed("mirmisc")
  ms_data <- get_ms_data(gene_predicate = ~median(.) > 0) %>%
    dplyr::select(
      mirvie_id, meta_pre_eclampsia,
      dplyr::any_of(mirmisc::get_gene_names())
    ) %>%
    dplyr::mutate(meta_pre_eclampsia = factor(meta_pre_eclampsia)) %>%
    dplyr::filter(!is.na(meta_pre_eclampsia))
  expect_error(
    rec <- recipes::recipe(ms_data) %>%
      recipes::update_role(dplyr::everything(), new_role = "predictor") %>%
      recipes::update_role(meta_pre_eclampsia, new_role = "outcome") %>%
      recipes::update_role(mirvie_id, new_role = "ID") %>%
      step_select_genes(recipes::all_predictors(), padj_cutoff = 0.5),
    "specify a.+condition.+column"
  )
  rec <- recipes::recipe(ms_data) %>%
    recipes::update_role(dplyr::everything(), new_role = "predictor") %>%
    recipes::update_role(meta_pre_eclampsia, new_role = "outcome") %>%
    recipes::update_role(mirvie_id, new_role = "ID") %>%
    step_select_genes(recipes::all_predictors(),
      condition = "meta_pre_eclampsia",
      padj_cutoff = 10^-30
    )
  expect_error(
    prep(rec$steps[[1]], training = ms_data, info = rec$term_info),
    "No good genes found"
  )
  rec <- recipes::recipe(ms_data) %>%
    recipes::update_role(dplyr::everything(), new_role = "predictor") %>%
    recipes::update_role(meta_pre_eclampsia, new_role = "outcome") %>%
    recipes::update_role(mirvie_id, new_role = "ID") %>%
    step_select_genes(dplyr::any_of("non_existent_col"),
      condition = "meta_pre_eclampsia",
      padj_cutoff = 10^-30
    )
  expect_error(
    prep(rec$steps[[1]], training = ms_data, info = rec$term_info),
    "No variables or terms were selected"
  )
  rec <- recipes::recipe(ms_data) %>%
    recipes::update_role(dplyr::everything(), new_role = "predictor") %>%
    recipes::update_role(meta_pre_eclampsia, new_role = "outcome") %>%
    recipes::update_role(mirvie_id, new_role = "ID") %>%
    step_select_genes(recipes::all_predictors(),
      condition = "meta_pre_eclampsia",
      padj_cutoff = 0.9
    )
  prepped_rec <- prep(rec)
  expect_error(
    bake(prepped_rec$steps[[1]], new_data = dplyr::select(ms_data, -AOX1)),
    "Not all genes found.+new_data.+example.+AOX1"
  )
  expect_equal(
    padj_cutoff(range = c(0, 0.5))$range,
    list(lower = 0, upper = 0.5)
  )
})
