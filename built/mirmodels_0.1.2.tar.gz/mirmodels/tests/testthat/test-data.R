test_that("data retrieval works", {
  skip_if_not_installed("mirmisc")
  kl_cpm <- get_kl_data(cpm = TRUE, tot_counts = TRUE,
                        remove_noncoding = FALSE, remove_pseudo = FALSE)
  gene_sums_per_sample <- kl_cpm %>%
    dplyr::select(dplyr::any_of(mirmisc::get_gene_names())) %>%
    rowSums()
  expect_equal(range(1e6 - gene_sums_per_sample), c(0, 0))
  kl_raw <- get_kl_data(remove_noncoding = FALSE, remove_pseudo = FALSE)
  expect_equal(
    kl_raw %>%
      dplyr::select(dplyr::any_of(mirmisc::get_gene_names())) %>%
      as.matrix() %>%
      rowSums(),
    kl_cpm$tot_counts
  )
  ga_cpm <- get_ga_data(cpm = TRUE)
  names_in_common <- intersect(names(ga_cpm), names(kl_cpm))
  expect_equal(
    dplyr::bind_rows(
      dplyr::select(ga_cpm, dplyr::all_of(names_in_common)),
      dplyr::select(kl_cpm, dplyr::all_of(names_in_common))
    ),
    get_combined_cohort_data(c("ga", "kl"), cpm = TRUE)
  )
  iopipmstup_medg0 <- get_combined_cohort_data(
    cohorts = c("io", "pi", "pm", "st", "up"),
    gene_predicate = ~ median(.) > 0
  ) %>%
    dplyr::select(dplyr::any_of(mirmisc::get_gene_names()))
  expect_true(all(purrr::map_lgl(iopipmstup_medg0, ~ median(.) > 0)))
  expect_equal(
    get_ms_data(),
    get_ms_data(feather_dir = mirmisc::get_feather_path())
  )
  expect_equal(
    get_dp_data(),
    get_dp_data(feather_dir = mirmisc::get_feather_path())
  )
})
