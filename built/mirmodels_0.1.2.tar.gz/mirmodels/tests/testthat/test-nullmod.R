test_that("comparison to null model works", {
  set.seed(1)
  suppressWarnings(
    expect_warning(
      for (i in seq_len(9)) {
        training_data <- data.frame(
          x1 = runif(99), x2 = runif(99),
          x3 = runif(99), y = runif(99)
        )
        train_gbm(
          training_data = training_data,
          outcome = "y",
          err_if_nullmod = FALSE,
          metric = "mae",
          selection_method = "abs",
          cv_nfolds = 2
        )
      },
      "null model was within 1 standard error of the fitted model"
    )
  )
  set.seed(1)
  expect_error(
    for (i in seq_len(9)) {
      training_data <- data.frame(
        x1 = runif(99), x2 = runif(99),
        x3 = runif(99), y = runif(99)
      )
      train_gbm(
        training_data = training_data,
        outcome = "y",
        err_if_nullmod = TRUE,
        metric = "mae",
        selection_method = "abs",
        cv_nfolds = 2
      )
    },
    "null model was within 1 standard error of the fitted model"
  )
  expect_error(
    for (i in seq_len(9)) {
      training_data <- data.frame(
        x1 = runif(99), x2 = runif(99),
        x3 = runif(99), y = runif(99)
      )
      tryCatch(
        train_gbm(
          training_data = training_data,
          outcome = "y",
          err_if_nullmod = TRUE,
          metric = "mae",
          selection_method = "abs",
          cv_nfolds = 2
        ),
        error = function(cnd) {
          if (stringr::str_detect(conditionMessage(cnd), "within")) {
            return(1)
          }
          stop(cnd)
        }
      )
    },
    "null model performed better than the fitted model"
  )
})
