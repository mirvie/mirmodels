test_that("get_metric_type() works", {
  expect_equal(get_metric_type("mape"), "numeric")
})

test_that("construct_df_na_err_msg() errors correctly", {
  expect_error(
    construct_df_na_err_msg(data.frame(x = 1)),
    "df.+must contain.+NA"
  )
})

test_that("`assert_yardstick_metric_names()` errors correctly", {
  expect_error(
    assert_yardstick_metric_names("logloss()"),
    "logloss.+not a valid yardstick metric name"
  )
})

test_that("`get_metric_names_from_set()` works", {
  expect_equal(
    get_metric_names_from_set(
      yardstick::metric_set(
        yardstick::rmse,
        yardstick::mae
      )
    ),
    c("rmse", "mae")
  )
})

test_that("`get_metric_type()` errors correctly", {
  skip_if_not_installed("mockery")
  mockery::stub(get_metric_type, "methods::is", FALSE)
  expect_error(get_metric_type("mae"),
               "Could not determine metric type")
})

test_that("`insist_mirmisc()` works", {
  skip_if_not_installed("mockery")
  if (rlang::is_installed("mirmisc")) expect_true(insist_mirmisc())
  mockery::stub(insist_mirmisc, "rlang::is_installed", FALSE)
  expect_error(insist_mirmisc(), "Package.+mirmisc.+is required")
})
