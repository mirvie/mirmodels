suppressWarnings(context("pca"))

test_that("compute_pcas() errors correctly", {
  skip_if_not_installed("mirmisc")
  ga_data <- get_ga_data(
    log2 = TRUE,
    gene_predicate = ~ median(.) > 0
  )
  expect_error(
    compute_pcas(ga_data,
      subset = intersect(
        mirmisc::get_gene_names(),
        names(ga_data)
      ),
      num_comp = 1e6
    ),
    paste(
      "With this data, the maximum number of components you can have is",
      min(dim(ga_data)) - 1
    )
  )
  expect_error(
    compute_pcas(ga_data),
    "columns.+must all be numeric.+Select a numeric.+subset"
  )
})
