test_that("`vimp()` works", {
  set.seed(1)
  iris_data <- janitor::clean_names(datasets::iris)
  iris_data_split <- rsample::initial_split(iris_data, strata = species)
  mod <- train_glm(
    training_data = rsample::training(iris_data_split),
    outcome = "species", metric = "mn_log_loss", lambda = 0,
    cv_nfolds = 4
  )
  expect_equal(
    vimp(mod) %>%
      dplyr::select(-rank) %>%
      dplyr::arrange(variable),
    vip::vi(workflows::pull_workflow_fit(mod)) %>%
      magrittr::set_names(tolower(names(.))) %>%
      dplyr::select(-sign) %>%
      dplyr::arrange(variable) %>%
      structure(class = dplyr::setdiff(class(.), "vi"), type = NULL)
  )
  expect_equal(vimp(list(mod, mod)), vimp(mod))
  expect_equal(
    vimp(structure(list(), class = "_nullmod")),
    dplyr::tibble(
      rank = integer(),
      variable = character(),
      importance = double()
    )
  )
  expect_error(vimp(1), "mod.+not.+model or list of models")
})
