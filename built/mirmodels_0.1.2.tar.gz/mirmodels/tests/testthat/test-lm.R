test_that(paste(
  "`train_lm()` has near-perfect prediction on a numeric",
  "outcome when given the outcome shifted as a predictor"
), {
  set.seed(1)
  pt_nearperfect_data <- get_pt_data(
    cpm = TRUE, log2 = TRUE,
    gene_predicate = ~ median(.) > 0
  ) %>%
    dplyr::mutate(out_shift = meta_weeks_to_delivery + 300) %>%
    dplyr::select(
      -cohort,
      -dplyr::starts_with("meta_", ignore.case = FALSE),
      meta_weeks_to_delivery
    )
  pt_nearperfect_data_split <- rsample::initial_split(
    pt_nearperfect_data,
    strata = meta_weeks_to_delivery
  )
  pt_nearperfect_training_data <- rsample::training(pt_nearperfect_data_split)
  pt_nearperfect_testing_data <- rsample::testing(pt_nearperfect_data_split)
  mod <- train_lm(pt_nearperfect_training_data, "meta_weeks_to_delivery",
    id_col = "mirvie_id", cv_nfolds = 4,
    metric = "mae"
  )
  preds <- stats::predict(mod, new_data = pt_nearperfect_testing_data)
  expect_lt(
    yardstick::mae_vec(
      preds[[1]],
      pt_nearperfect_testing_data$meta_weeks_to_delivery
    ),
    stats::sd(pt_nearperfect_testing_data$meta_weeks_to_delivery) / 10
  )
})

test_that("With random predictors and enough data, null model is returned", {
  set.seed(1)
  x <- replicate(99, runif(9999)) %>%
    magrittr::set_names(stringr::str_c("x", seq_along(.))) %>%
    as.data.frame()
  data <- x %>%
    dplyr::mutate(y = runif(nrow(.), 4, 6))
  data_split <- rsample::initial_split(data)
  training_data <- rsample::training(data_split)
  expect_error(
    mod <- train_lm(training_data, "y",
      cv_nfolds = 4,
      selection_method = "abs",
      metric = "mae",
      include_nullmod = TRUE, err_if_nullmod = TRUE
    ),
    "null model"
  )
  expect_warning(
    mod <- train_lm(training_data, "y",
      cv_nfolds = 4,
      selection_method = "abs",
      metric = "mae",
      include_nullmod = TRUE, warn_if_nullmod = TRUE
    ),
    "Returning the null model"
  )
  expect_equal(
    workflows::pull_workflow_fit(mod)$spec$method$fit$func,
    c(fun = "nullmodel")
  )
})

test_that("Model can overfit to great prediction on the training data", {
  skip_if_not_installed("datasets")
  iris_data <- janitor::clean_names(datasets::iris)
  mod <- train_lm(
    iris_data, "petal_length",
    lambda = 0,
    cv_nfolds = 4,
    selection_method = "abs",
    metric = "rmse",
    include_nullmod = FALSE
  )
  truth <- iris_data$petal_length
  preds <- predict(mod, new_data = iris_data)[[1]]
  expect_lt(median(abs(truth - preds)), 0.2)
})

test_that("train_lm() errors as expected", {
  training_data <- dplyr::tibble(x = list(1:2), y = 1:2)
  expect_error(
    train_lm(
      training_data = training_data,
      outcome = "y"
    ),
    paste0(
      "All elements of.+training_data.+must.+numeric.+factor.+character",
      ".+column.+x.+is not"
    )
  )
  training_data <- dplyr::tibble(x = 1:2, y = 1)
  expect_error(
    train_lm(
      training_data = training_data,
      outcome = "y"
    ),
    "Your outcome must have at least two distinct values"
  )
  training_data$y <- as.logical(round(runif(nrow(training_data))))
  expect_error(
    train_lm(
      training_data = training_data,
      outcome = "y"
    ),
    "Your outcome should not be of logical.+type."
  )
  training_data$y <- runif(nrow(training_data))
})
