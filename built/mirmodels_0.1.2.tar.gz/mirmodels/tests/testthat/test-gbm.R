test_that(paste(
  "`train_gbm()` has near-perfect prediction on a numeric",
  "outcome when given the squared outcome as a predictor"
), {
  pt_nearperfect_data <- get_pt_data(
    gene_predicate = ~ stats::median(.) > 0
  ) %>%
    dplyr::mutate(out_sq = meta_weeks_to_delivery^2) %>%
    dplyr::select(
      -cohort,
      -dplyr::starts_with("meta_", ignore.case = FALSE),
      meta_weeks_to_delivery
    )
  pt_nearperfect_data_split <- rsample::initial_split(
    pt_nearperfect_data,
    strata = meta_weeks_to_delivery
  )
  pt_nearperfect_training_data <- rsample::training(pt_nearperfect_data_split)
  pt_nearperfect_testing_data <- rsample::testing(pt_nearperfect_data_split)
  mod <- train_gbm(pt_nearperfect_training_data, "meta_weeks_to_delivery",
    hyper_param_grid = list(
      trees = c(100),
      tree_depth = 1,
      learn_rate = c(0.1)
    ),
    id_col = "mirvie_id", cv_nfolds = 2, cv_nreps = 2,
    simplicity_params = c("trees", "learn_rate"),
    metric = "mae"
  )
  preds <- stats::predict(mod, new_data = pt_nearperfect_testing_data)
  expect_lt(
    yardstick::mae_vec(
      preds$.pred,
      pt_nearperfect_testing_data$meta_weeks_to_delivery
    ),
    stats::sd(pt_nearperfect_testing_data$meta_weeks_to_delivery) / 10
  )
  mod <- train_gbm(pt_nearperfect_training_data, "meta_weeks_to_delivery",
    hyper_param_grid = list(
      trees = c(100),
      tree_depth = 1,
      learn_rate = c(0.1)
    ),
    id_col = "mirvie_id", cv_nfolds = 3,
    simplicity_params = c("trees", "learn_rate"),
    metric = "mae"
  )
  preds <- stats::predict(mod, new_data = pt_nearperfect_testing_data)
  expect_lt(
    yardstick::mae_vec(
      preds$.pred,
      pt_nearperfect_testing_data$meta_weeks_to_delivery
    ),
    stats::sd(pt_nearperfect_testing_data$meta_weeks_to_delivery) / 10
  )
})

test_that(paste(
  "`train_gbm()` has near-perfect prediction on a binarized",
  "(greater or less than the mean) numeric outcome when given",
  "the squared numeric outcome as a predictor"
), {
  rs_nearperfect_data <- get_rs_data(
    gene_predicate = ~ stats::median(.) > 0
  ) %>%
    dplyr::filter(!is.na(meta_deliveryga)) %>%
    dplyr::mutate(
      out_sq = meta_deliveryga^2,
      less_greater = factor(dplyr::if_else(
        meta_deliveryga <= mean(meta_deliveryga),
        "less", "greater"
      ))
    ) %>%
    dplyr::select(-dplyr::starts_with("meta_", ignore.case = FALSE), -cohort)
  rs_nearperfect_data_split <- rsample::initial_split(rs_nearperfect_data,
    strata = less_greater
  )
  rs_nearperfect_training_data <- rsample::training(rs_nearperfect_data_split)
  rs_nearperfect_testing_data <- rsample::testing(rs_nearperfect_data_split)
  mod <- train_gbm(rs_nearperfect_training_data, "less_greater",
    hyper_param_grid = list(
      trees = c(100),
      tree_depth = 1,
      learn_rate = c(0.1)
    ),
    id_col = "mirvie_id", cv_nfolds = 3, strata = "less_greater",
    simplicity_params = c("trees", "learn_rate"),
    metric = "mn_log_loss"
  )
  preds <- stats::predict(mod, new_data = rs_nearperfect_testing_data)
  expect_lte(sum(preds[[1]] != rs_nearperfect_testing_data$less_greater), 1)
})

test_that(paste(
  "`train_gbm()` has perfect categorical predictions with",
  "a perfect predictor"
), {
  ga_perfect_data <- get_ga_data(
    gene_predicate = ~ median(.) > 0
  ) %>%
    dplyr::mutate(
      race_otherized_pred = forcats::fct_lump_prop(meta_major_race, 0.1),
      race_otherized_pred = dplyr::if_else(
        is.na(race_otherized_pred),
        "Other",
        as.character(race_otherized_pred)
      ),
      race_otherized_pred = factor(race_otherized_pred),
      race_otherized_out = race_otherized_pred
    )
  set.seed(1)
  ga_perfect_data_split <- rsample::initial_split(ga_perfect_data,
    strata = race_otherized_out
  )
  ga_perfect_training_data <- rsample::training(ga_perfect_data_split)
  ga_perfect_testing_data <- rsample::testing(ga_perfect_data_split)
  mod <- train_gbm(ga_perfect_training_data, "race_otherized_out",
    hyper_param_grid = list(
      trees = 100,
      tree_depth = 1,
      learn_rate = 0.1
    ),
    id_col = "mirvie_id", cv_nfolds = 3,
    simplicity_params = c("trees", "learn_rate"),
    metric = "accuracy"
  )
  preds <- stats::predict(mod, new_data = ga_perfect_testing_data)
  expect_equal(preds[[1]], ga_perfect_testing_data$race_otherized_out)
})

test_that("Repeated runs produce the same output", {
  pt_data <- get_pt_data(
    log2 = TRUE,
    gene_predicate = ~ stats::median(.) > 0
  ) %>%
    dplyr::select(
      -dplyr::starts_with("meta_", ignore.case = FALSE),
      meta_weeks_to_delivery
    )
  pt_data_split <- rsample::initial_split(pt_data)
  pt_training_data <- rsample::training(pt_data_split)
  pt_testing_data <- rsample::testing(pt_data_split)
  models <- as.list(1:2)
  for (i in seq_along(models)) {
    set.seed(1)
    models[[i]] <- train_gbm(pt_training_data, "meta_weeks_to_delivery",
      hyper_param_grid = list(
        trees = c(50, 100),
        tree_depth = 1,
        learn_rate = c(0.1)
      ),
      id_col = "mirvie_id", cv_nfolds = 3,
      simplicity_params = c("trees", "learn_rate"),
      metric = "mae",
      include_nullmod = FALSE
    )
  }
  expect_equal(
    stats::predict(models[[1]], new_data = pt_testing_data),
    stats::predict(models[[2]], new_data = pt_testing_data)
  )
})

test_that("With random predictors and enough data, null model is returned", {
  set.seed(1)
  x <- replicate(99, runif(9999)) %>%
    magrittr::set_names(stringr::str_c("x", seq_along(.))) %>%
    as.data.frame()
  data <- x %>%
    dplyr::mutate(y = runif(nrow(.), 4, 6))
  data_split <- rsample::initial_split(data)
  training_data <- rsample::training(data_split)
  expect_error(
    mod <- train_gbm(training_data, "y",
      hyper_param_grid = list(
        trees = c(100),
        tree_depth = 2,
        learn_rate = c(0.5)
      ),
      cv_nfolds = 3,
      selection_method = "abs",
      metric = "mae",
      include_nullmod = TRUE, err_if_nullmod = TRUE
    ),
    "null model"
  )
  expect_warning(
    mod <- train_gbm(training_data, "y",
      hyper_param_grid = list(
        trees = c(100),
        tree_depth = 2,
        learn_rate = c(0.51)
      ),
      cv_nfolds = 3,
      selection_method = "abs",
      metric = "mae",
      include_nullmod = TRUE, warn_if_nullmod = TRUE
    ),
    "Returning the null model"
  )
  expect_equal(
    workflows::pull_workflow_fit(mod)$spec$method$fit$func,
    c(fun = "nullmodel")
  )
})

test_that("The model can overfit to perfect prediction on the training data", {
  skip_if_not_installed("datasets")
  iris_data <- janitor::clean_names(datasets::iris)
  mod <- train_gbm(iris_data, "species",
    hyper_param_grid = list(
      trees = c(100),
      tree_depth = 2,
      learn_rate = c(0.5)
    ),
    cv_nfolds = 2,
    selection_method = "abs",
    metric = "accuracy",
    include_nullmod = FALSE
  )
  truth <- iris_data$species
  preds <- stats::predict(mod, new_data = iris_data)[[1]]
  expect_equal(truth, preds)
})

test_that("train_gbm() errors as expected", {
  training_data <- dplyr::tibble(x = list(1:2), y = 1:2)
  expect_error(
    train_gbm(
      training_data = training_data,
      outcome = "y"
    ),
    paste0(
      "All elements of.+training_data.+must.+numeric.+factor.+character",
      ".+column.+x.+is not"
    )
  )
  training_data <- dplyr::tibble(x = 1:2, y = 1)
  expect_error(
    train_gbm(
      training_data = training_data,
      outcome = "y"
    ),
    "Your outcome must have at least two distinct values"
  )
  training_data$y <- as.logical(round(runif(nrow(training_data))))
  expect_error(
    train_gbm(
      training_data = training_data,
      outcome = "y"
    ),
    "Your outcome should not be of logical.+type."
  )
  training_data$y <- 3:4
  expect_error(
    train_gbm(
      training_data = training_data,
      outcome = "y", selection_method = "Breiman", metric = "rmse"
    ),
    "When using.+Breiman.+specify at least one tuning parameter"
  )
  expect_error(
    train_gbm(
      training_data = training_data,
      outcome = "y", selection_method = "Breiman", metric = "rmse",
      simplicity_params = c("notparam")
    ),
    paste0(
      "variables.+in.+simplicity_params.+must be.+in.+hyper_param_grid",
      ".+notparam.+not.+in.+hyper_param_grid"
    )
  )
  expect_error(
    train_gbm(
      training_data = get_bw_data(),
      outcome = "meta_mom_bmi",
      metric = "mae",
      selection_method = "abs"
    ),
    "outcome must not contain.+NA"
  )
})
