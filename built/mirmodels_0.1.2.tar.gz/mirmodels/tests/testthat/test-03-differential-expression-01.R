test_that("DE methods find PAPPA2 for BWH PE", {
  bw_data <- get_bw_data(gene_predicate = ~ median(.) > 0)
  de <- edger(bw_data, "meta_pre_eclampsia")
  expect_lt(de[de$gene == "PAPPA2", "padj"], 0.05)
  de <- cor_de(bw_data, "meta_pre_eclampsia")
  expect_lt(de[de$gene == "PAPPA2", "pvalue"], 0.001)
  de <- deseq(bw_data, "meta_pre_eclampsia", quiet = TRUE)
  expect_lt(de[de$gene == "PAPPA2", "padj"], 0.05)
  de_shrunk <- deseq(bw_data, "meta_pre_eclampsia",
    shrink = TRUE, quiet = TRUE
  )
  expect_lt(
    de_shrunk[de_shrunk$gene == "PAPPA2", "log2fc"],
    de[de$gene == "PAPPA2", "log2fc"]
  )
  bwms_data <- get_combined_cohort_data(
    c("bw", "ms"),
    gene_predicate = ~ stats::median(.) > 0
  ) %>%
    dplyr::filter(!is.na(meta_pre_eclampsia))
  expect_lt(
    deseq(bwms_data, "meta_pre_eclampsia", batch = "cohort", quiet = TRUE) %>%
      dplyr::filter(gene == "PAPPA2") %>%
      dplyr::pull(padj),
    0.01
  )
  expect_lt(
    edger(bwms_data, "meta_pre_eclampsia", batch = "cohort") %>%
      dplyr::filter(gene == "PAPPA2") %>%
      dplyr::pull(padj),
    0.01
  )
})
