test_that("files in /mnt/storage/FullDatasets agree", {
  skip_if_not_installed("mirmisc")
  skip_if_not(fs::dir_exists("/mnt/storage/FullDatasets"))
  gene_converter <- readr::read_csv(
    system.file("extdata", "ensembl-to-gene-curated.csv",
      package = "mirmisc"
    ),
    col_types = readr::cols(), progress = FALSE
  )
  gene_converter <- magrittr::set_names(
    gene_converter$GeneName,
    gene_converter$EnsemblGeneID
  )
  expect_rawtxt_eq_feather <- function(rawtxt_path, feather_path) {
    print(rawtxt_path)
    checkmate::assert_file_exists(rawtxt_path)
    checkmate::assert_file_exists(feather_path)
    rawtxt <- readr::read_tsv(rawtxt_path,
      col_types = readr::cols(),
      progress = FALSE
    )
    rawtxt <- data.matrix(rawtxt[-1]) %>%
      magrittr::set_rownames(rawtxt[[1]]) %>%
      t() %>%
      dplyr::as_tibble(rownames = "mirvie_id")
    convertable_names <- dplyr::intersect(names(rawtxt), names(gene_converter))
    new_rawtxt_names <- dplyr::if_else(
      names(rawtxt) %in% convertable_names,
      gene_converter[names(rawtxt)], names(rawtxt)
    )
    names(rawtxt) <- new_rawtxt_names
    feather <- arrow::read_feather(feather_path)
    expect_true(all(feather$mirvie_id %in% rawtxt$mirvie_id))
    expect_true(all(names(feather) %in% names(rawtxt)))
    rawtxt <- dplyr::filter(rawtxt, mirvie_id %in% feather$mirvie_id) %>%
      dplyr::select(dplyr::all_of(names(feather))) %>%
      dplyr::arrange(mirvie_id)
    feather <- dplyr::arrange(feather, mirvie_id)
    expect_equal(rawtxt[1:9], feather[1:9])
    expect_equal(rawtxt, feather)
    invisible(TRUE)
  }
  paths <- dplyr::tibble(
    rawtxt_path = fs::dir_ls(
      "~/Desktop/FullDatasets/raw",
      glob = "*_??_genes_counts.txt"
    ),
    cohort = stringr::str_extract(rawtxt_path, "_.._")
  ) %>%
    dplyr::mutate(cohort = stringr::str_sub(cohort, 2, 3)) %>%
    dplyr::filter(
      cohort %in% c(
        "ST", "GA", "PG", "MS", "IO", "RS", "PM", "VG", "PT",
        "KL", "BW", "PI"
      )
    ) %>%
    dplyr::mutate(
      feather_path = purrr::map_chr(
        cohort,
        ~ stringr::str_subset(
          fs::dir_ls("~/Desktop/FullDatasets/feathers", regexp = "counts"),
          .
        )
      )
    ) %>%
    dplyr::select(-cohort)
  purrr::pmap(paths, expect_rawtxt_eq_feather)
})

# MS and IO missing first few
# PT Re-Cap ?
