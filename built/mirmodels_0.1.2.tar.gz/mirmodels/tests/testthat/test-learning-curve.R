suppressWarnings(context("learning-curve"))

test_that("Learning curves error properly", {
  data("BostonHousing", package = "mlbench")
  bh <- janitor::clean_names(BostonHousing) %>%
    dplyr::select_if(is.numeric)
  model_evaluate <- function(training_data, testing_data) {
    trained_mod <- lm(medv ~ ., training_data)
    training_preds <- predict(trained_mod, newdata = training_data)
    preds <- predict(trained_mod, newdata = testing_data)
    c(
      train = yardstick::mae_vec(training_data$medv, training_preds),
      test = yardstick::mae_vec(testing_data$medv, preds)
    )
  }
  mlc <- mlc0 <- suppressWarnings(learn_curve(model_evaluate, bh, "medv",
    training_fracs = seq(0, 0.9, length.out = 10),
    testing_frac = c(0.25, 0.5), repeats = 8,
    strata = "medv",
    
  ))
  mlc <- dplyr::filter(mlc0, rep == 1)
  expect_error(
    autoplot(mlc, meansd = TRUE),
    "can only use.+meansd = TRUE.+if.+repeats.+greater than 1."
  )
})

test_that("Learning curve calculations error correctly", {
  iris_data <- janitor::clean_names(datasets::iris)
  iris_data_split <- rsample::initial_split(iris_data, strata = species)
  iris_data_training <- rsample::training(iris_data_split)
  iris_data_testing <- rsample::testing(iris_data_split)
  expect_error(
    learn_curve(
      model_evaluate = function(training_data, testing_data) {
        return(NA)
      },
      iris_data, "species", testing_frac = c(0.2, 0.3), repeats = 3
    ),
    "must return a named length 2 numeric vector"
  )
  expect_error(
    learn_curve(
      model_evaluate = function(training_data, testing_data) {
        return(c(exam = 1, test = 2))
      },
      iris_data, "species", testing_frac = c(0.2, 0.3), repeats = 3
    ),
    "must.+names .+cv.+test.+or.+train.+test"
  )
  expect_equal(
    {
      set.seed(1)
      learn_curve(
        model_evaluate = function(training_data, testing_data) {
          return(c(train = 1, test = 2))
        },
        iris_data, "species", testing_frac = c(0.2, 0.3), repeats = 3
      )
    },
    {
      set.seed(1)
      learn_curve(
        model_evaluate = function(training_data, testing_data) {
          return(c(test = 2, train = 1))
        },
        iris_data, "species", testing_frac = c(0.2, 0.3), repeats = 3
      )
    }
  )
  model_evaluate <- function(training_data, testing_data) {
    trained_mod <- train_gbm(
      training_data = training_data,
      metric = "mn_log_loss",
      outcome = "species",
      simplicity_params = c("trees", "learn_rate")
    )
    preds <- predict(trained_mod, new_data = testing_data, type = "prob")
    actuals <- testing_data[["species"]]
    c(
      cv = attr(trained_mod, "cv_performance")[["mean"]],
      test = yardstick::mn_log_loss_vec(actuals, as.matrix(preds))
    )
  }

  expect_error(
    learn_curve(
      model_evaluate = model_evaluate,
      training_data = iris_data_training, testing_data = iris_data_testing,
      outcome = "species", testing_frac = c(0.2, 0.3)
    ),
    "If you specify .+testing_data.+testing_frac.+must be.+NULL"
  )
  expect_error(
    learn_curve(
      model_evaluate = model_evaluate,
      training_data = iris_data_training, testing_data = NULL,
      outcome = "species", testing_frac = NULL
    ),
    "testing_data.+and.+testing_frac.+both.+NULL"
  )
  expect_error(
    learn_curve(
      model_evaluate = model_evaluate,
      training_data = iris_data_training, testing_data = NULL,
      outcome = "species", testing_frac = 1
    ),
    "elements.+testing_frac.+must.+between.+0.+1.+not inclusive"
  )
  expect_error(
    learn_curve(
      model_evaluate = model_evaluate,
      training_data = iris_data_training, testing_data = iris_data_testing,
      outcome = "species", repeats = 9
    ),
    "If.+repeats.+greater than 1.+testing_data.+must.+NULL"
  )
})

test_that("verify_mirvie_learning_curve() errors correctly", {
  iris_data <- janitor::clean_names(datasets::iris)
  model_evaluate <- function(training_data, testing_data) {
    trained_mod <- train_gbm(
      training_data = training_data,
      metric = "mn_log_loss",
      outcome = "species",
      hyper_param_grid = list(
        trees = c(20, 50),
        tree_depth = c(1, 2),
        learn_rate = c(0.01, 0.1)
      ),
      simplicity_params = c("trees", "learn_rate")
    )
    preds <- predict(trained_mod, new_data = testing_data, type = "prob")
    actuals <- testing_data[["species"]]
    c(
      cv = attr(trained_mod, "cv_performance")[["mean"]],
      test = yardstick::mn_log_loss_vec(actuals, as.matrix(preds))
    )
  }
  mlc <- learn_curve(
    model_evaluate = model_evaluate,
    training_data = iris_data,
    outcome = "species", testing_frac = 0.2
  )
  expect_true(verify_mirvie_learning_curve(mlc))
  mlc$cv <- as.integer(mlc$cv)
  expect_error(
    verify_mirvie_learning_curve(mlc),
    paste0(
      "column.+cv.+should be of type.+double.+",
      "Currently.+of type.+integer"
    )
  )
  mlc$rep <- as.double(mlc$rep)
  expect_error(
    verify_mirvie_learning_curve(mlc),
    paste0(
      "column.+rep.+should be of type.+integer.+",
      "Currently.+of type.+double"
    )
  )
})

test_that("mirvie_learning_curve_cv() errors correctly", {
  iris_data <- janitor::clean_names(datasets::iris)
  rec <- recipes::recipe(species ~ ., data = iris_data)
  mod <- parsnip::multinom_reg(penalty = 0, mixture = 0) %>%
    parsnip::set_engine("glmnet")
  wf <- workflows::workflow() %>%
    workflows::add_recipe(rec) %>%
    workflows::add_model(mod)
  metric_calculator <- ~ yardstick::mn_log_loss(
    ., species, dplyr::starts_with(".pred_"), -.pred_class
  )$.estimate
  lccv <- learn_curve_cv(iris_data, wf, 2:4, 3, metric_calculator,
    strata = "species", pkgs = character(0)
  )
  expect_error(
    learn_curve_cv(iris_data, wf, 2:4, 3, function(...) 1:2),
    "metric_calculator.+must output a single number.+This.+integer.+length.+2"
  )
})
