test_that("`multi_lm()` and friends work", {
  skip_if_not_installed("mirmisc")
  gars_data <- get_combined_cohort_data(c("ga", "rs"),
    gene_predicate = ~ median(.) > 0,
    cpm = TRUE
  ) %>%
    dplyr::select(
      mirvie_id, cohort, meta_major_race, meta_collectionga,
      dplyr::any_of(mirmisc::get_gene_names())
    ) %>%
    dplyr::filter(!is.na(meta_major_race)) %>%
    dplyr::mutate(
      meta_major_race = factor(meta_major_race)
    )
  gars_data_genes <- dplyr::select(
    gars_data,
    dplyr::any_of(mirmisc::get_gene_names())
  )
  xs <- c("cohort", "meta_major_race", "meta_collectionga")
  ys <- gars_data %>%
    dplyr::select(dplyr::any_of(mirmisc::get_gene_names())) %>%
    purrr::map_dbl(sum) %>%
    sort() %>%
    tail(1000) %>%
    names() %>%
    c("PAPPA2") %>%
    unique()
  lms <- multi_lm(gars_data, xs, ys, robust = FALSE)
  res <- multi_aov(lms, gars_data, type = 1)
  expect_equal(
    res %>%
      dplyr::filter(y == "PAPPA2", x == "meta_collectionga") %>%
      dplyr::pull(pctvarexp),
    11,
    tolerance = 1
  )
  res_summary <- summary(res, 0.95, 0.99)
  expect_equal(
    names(res_summary),
    c(
      "x", "med_pctvarexp", "mean_pctvarexp", "max_pctvarexp",
      "pctl95_pctvarexp", "pctl99_pctvarexp"
    )
  )
  expect_gt(res_summary[res_summary$x == "Residuals", ][["med_pctvarexp"]], 70)
  expect_error(
    summary(res, 0.95, 0.99, "a"),
    "Arguments passed in ... must all be numbers between 0 and 1."
  )
  lms2 <- multi_lm(gars_data, xs, ys, robust = FALSE)
  res2 <- multi_aov(lms2, gars_data, type = 2)
  expect_lt(summary(res)$med_pctvarexp[1], summary(res2)$med_pctvarexp[1])
  expect_error(
    multi_aov(multi_lm(gars_data, xs, ys, robust = TRUE),
      gars_data,
      type = 2
    ),
    "Cannot perform type II ANOVA on a robust linear model"
  )
  mr <- multi_resids(lms,
    lms_data = gars_data, reset_mean_med = FALSE
  )
  mr_mean_reset <- multi_resids(lms,
    lms_data = gars_data,
    reset_mean_med = TRUE
  )
  expect_equal(
    purrr::map_dbl(gars_data_genes, mean),
    purrr::map_dbl(
      dplyr::select(
        mr_mean_reset,
        dplyr::any_of(mirmisc::get_gene_names())
      ),
      mean
    )
  )
})

test_that("`multi_lm()` and friends error correctly", {
  df <- dplyr::tibble(
    x1 = 1:100, x2 = x1 + 1, x3 = x2 + 1, x4 = NA, x5 = 5,
    y1 = 1, y2 = 2
  )
  expect_error(
    multi_lm(df, xs = paste0("x", 1:4), ys = c("y1", "y2")),
    paste0(
      "df.xs.+should not contain.+NA.+",
      "x4.+has an.+NA.+row.+1"
    )
  )
  df$x4 <- 4
  df$y1 <- NA_real_
  expect_error(
    multi_lm(df, xs = paste0("x", 1:4), ys = c("y1", "y2")),
    paste0(
      "df.ys.+should not contain.+NA.+",
      "column.+y1.+has an.+NA.+row.+1"
    )
  )
  df$y1 <- 1
  lms <- multi_lm(df, xs = paste0("x", 1:4), ys = c("y1", "y2"), robust = FALSE)
  expect_error(
    multi_resids(lms, reset_mean_med = TRUE),
    "To use.+reset_mean_med.+lms_data.+cannot be.+NULL"
  )
})
