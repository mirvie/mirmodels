library(testthat)
library(mirmodels)

test_check("mirmodels")
